package com.Fit;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.lang.Math;



public class Client extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String calculatorType = request.getParameter("calculator");

        if (calculatorType == null) {
            showMainPage(out);
        } else {
            showCalculator(out, calculatorType);
        }
    }

    @Override
protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    response.setContentType("text/html;charset=UTF-8");
    PrintWriter out = response.getWriter();
    String calculatorType = request.getParameter("calculator");
    
    // TAMBAH CHECK NULL NI
    if (calculatorType == null) {
        showMainPage(out);
        return;  // keluar dari method
    }
    
    switch (calculatorType) {
        case "userinfo": calculateUserInfo(request, out); break;
        case "bmi": calculateBMI(request, out); break;
        case "calorie": calculateCalorieBurn(request, out); break;
        case "bodyfat": calculateBodyFat(request, out); break;
        case "sleep": calculateSleep(request, out); break;
        case "cycle": calculateMenstrualCycle(request, out); break;
        case "age": calculateAge(request, out); break;
        default: showMainPage(out);
    }
}


    //UI DESIGN PAPARAN HOMEPAGE DEPAN SEKALI
    private void showMainPage(PrintWriter out) {
        out.println("<!DOCTYPE html><html><head><title>Health & Fitness Calculator</title>");
        out.println("<style>");
        out.println("body { font-family: Arial; background: linear-gradient(135deg, #667eea, #764ba2); padding: 20px; }");
        out.println(".container { max-width: 800px; margin: auto; color: white; text-align: center; }");
        out.println(".calculator-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; }");
        out.println(".calculator-button { background: rgba(255,255,255,0.1); padding: 20px; border-radius: 10px; cursor: pointer; transition: 0.3s; }");
        out.println(".calculator-button:hover { background: rgba(255,255,255,0.2); transform: translateY(-5px); }");
        out.println("</style></head><body>");
        out.println("<div class='container'><h1>Personal Health & Fitness Calculator</h1>");
        out.println("<p>Your Complete Wellness Companion</p><div class='calculator-grid'>");

        String[][] calculators = {
            {"userinfo", "👤 User Profile", "View and manage your health info"},
            {"bmi", "⚖️ BMI Calculator", "Calculate your Body Mass Index"},
            {"calorie", "🔥 Calorie Burn", "Track calories burned during activities"},
            {"bodyfat", "🏃 Body Fat", "Estimate your body fat percentage"},
            {"sleep", "😴 Sleep Tracker", "Sleep duration recommendation"},
            {"cycle", "🌸 Cycle Calculator", "Track menstrual cycle"},
            {"age", "🎂 Age Calculator", "Calculate age from IC"}
        };

        for (String[] c : calculators) {
            out.println("<div class='calculator-button' onclick=\"location.href='Client?calculator=" + c[0] + "'\">");
            out.println("<h3>" + c[1] + "</h3><p>" + c[2] + "</p></div>");
        }

        out.println("</div></div></body></html>");
    }

    private void showCalculator(PrintWriter out, String type) {
        out.println("<!DOCTYPE html><html><head><title>" + type.toUpperCase() + " Calculator</title>");
        out.println("<style>");
        out.println("body { font-family: Arial; background: linear-gradient(135deg, #667eea, #764ba2); padding: 20px; }");
        out.println(".container { max-width: 600px; margin: auto; background: white; padding: 30px; border-radius: 10px; }");
        out.println(".form-group { margin: 15px 0; } label { display: block; margin-bottom: 5px; font-weight: bold; }");
        out.println("input, select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; }");
        out.println("button { background: #667eea; color: white; padding: 12px 30px; border: none; border-radius: 5px; cursor: pointer; }");
        out.println("button:hover { background: #5a67d8; } .back-btn { margin-top: 20px; }");
        out.println("</style></head><body><div class='container'>");

        switch (type) {
            case "userinfo": showUserInfoForm(out); break;
            case "bmi": showBMIForm(out); break;
            case "calorie": showCalorieBurnForm(out); break;
            case "bodyfat": showBodyFatForm(out); break;
            case "sleep": showSleepForm(out); break;
            case "cycle": showCycleForm(out); break;
            case "age": showAgeForm(out); break;
            default: out.println("<p>Calculator not available.</p>");
        }

        out.println("</div></body></html>");
    }


    // UI DESIGN UNTUK SETIAP MODULES
    private void showUserInfoForm(PrintWriter out) {
        out.println("<form method='post'><input type='hidden' name='calculator' value='userinfo'>");
        out.println("<div class='form-group'><label>Name:</label><input type='text' name='name' required></div>");
        out.println("<div class='form-group'><label>Age:</label><input type='number' name='age' required></div>");
        out.println("<div class='form-group'><label>Gender:</label><select name='gender'><option>Male</option><option>Female</option></select></div>");
        out.println("<div class='form-group'><label>Height (cm):</label><input type='number' name='height' required></div>");
        out.println("<div class='form-group'><label>Weight (kg):</label><input type='number' name='weight' required></div>");
        out.println("<button type='submit'>Save Profile</button></form>");
    }

     private void showBMIForm(PrintWriter out) {
    out.println("<!DOCTYPE html><html><head><title>BMI Calculator</title>");
    out.println("<style>");
    out.println("* { margin: 0; padding: 0; box-sizing: border-box; }");
    out.println("body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding: 20px; }");
    out.println(".container { max-width: 480px; margin: 50px auto; background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(10px); border-radius: 24px; padding: 40px 32px; box-shadow: 0 20px 40px rgba(0,0,0,0.1); }");
    out.println(".header { text-align: center; margin-bottom: 32px; }");
    out.println(".title { font-size: 28px; font-weight: 600; color: #6c63ff; margin-bottom: 8px; display: flex; align-items: center; justify-content: center; gap: 12px; }");
    out.println(".form-group { margin-bottom: 24px; }");
    out.println(".label { display: flex; align-items: center; gap: 8px; font-size: 16px; font-weight: 500; color: #374151; margin-bottom: 8px; }");
    out.println(".input { width: 100%; padding: 16px 20px; border: 2px solid #e5e7eb; border-radius: 12px; font-size: 16px; background: white; transition: all 0.3s ease; outline: none; }");
    out.println(".input:focus { border-color: #6c63ff; box-shadow: 0 0 0 3px rgba(108, 99, 255, 0.1); }");
    out.println(".input::placeholder { color: #9ca3af; }");
    out.println(".select { width: 100%; padding: 16px 20px; border: 2px solid #e5e7eb; border-radius: 12px; font-size: 16px; background: white; cursor: pointer; transition: all 0.3s ease; outline: none; appearance: none; background-image: url('data:image/svg+xml;charset=US-ASCII,<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 4 5\"><path fill=\"%23666\" d=\"M2 0L0 2h4zm0 5L0 3h4z\"/></svg>'); background-repeat: no-repeat; background-position: right 16px center; background-size: 12px; }");
    out.println(".select:focus { border-color: #6c63ff; box-shadow: 0 0 0 3px rgba(108, 99, 255, 0.1); }");
    out.println(".btn-primary { width: 100%; background: linear-gradient(135deg, #6c63ff, #574fd6); color: white; border: none; padding: 18px 24px; border-radius: 12px; font-size: 16px; font-weight: 600; cursor: pointer; transition: all 0.3s ease; display: flex; align-items: center; justify-content: center; gap: 8px; margin-top: 8px; }");
    out.println(".btn-primary:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(108, 99, 255, 0.3); }");
    out.println(".btn-secondary { width: 100%; background: #f3f4f6; color: #374151; border: none; padding: 16px 24px; border-radius: 12px; font-size: 16px; font-weight: 500; cursor: pointer; transition: all 0.3s ease; display: flex; align-items: center; justify-content: center; gap: 8px; margin-top: 16px; }");
    out.println(".btn-secondary:hover { background: #e5e7eb; transform: translateY(-1px); }");
    out.println(".input-wrapper { position: relative; }");
    out.println(".input-icon { position: absolute; right: 16px; top: 50%; transform: translateY(-50%); font-size: 18px; }");
    out.println(".valid-icon { color: #10b981; }");
    out.println(".invalid-icon { color: #ef4444; }");
    out.println(".error-message { color: #ef4444; font-size: 14px; margin-top: 6px; display: none; }");
    out.println(".error-alert { background: #fef2f2; border: 2px solid #fecaca; border-radius: 12px; padding: 16px; margin-bottom: 20px; display: none; }");
    out.println(".error-alert-content { display: flex; align-items: center; gap: 12px; }");
    out.println(".error-alert-icon { font-size: 20px; color: #dc2626; }");
    out.println(".error-alert-text { color: #dc2626; font-weight: 500; font-size: 15px; }");
    out.println(".btn-primary:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }");
    out.println("@media (max-width: 640px) { .container { margin: 20px auto; padding: 32px 24px; } .title { font-size: 24px; } }");
    out.println("</style></head><body>");
    out.println("<div class='container'>");
    out.println("<div class='header'>");
    out.println("<h1 class='title'>📏 BMI Calculator</h1>");
    out.println("<div class='error-alert' id='errorAlert'>");
    out.println("<div class='error-alert-content'>");
    out.println("<span class='error-alert-icon'>⚠️</span>");
    out.println("<span class='error-alert-text' id='errorAlertText'>Please check your input values!</span>");
    out.println("</div>");
    out.println("</div>");
    out.println("</div>");
    out.println("<form method='post'>");
    out.println("<input type='hidden' name='calculator' value='bmi'>");
    
    out.println("<div class='form-group'>");
    out.println("<label class='label'>📐 Height (cm):</label>");
    out.println("<div class='input-wrapper'>");
    out.println("<input type='number' name='height' id='heightInput' class='input' placeholder='Enter height (50-250 cm)' min='50' max='250' step='0.1' required>");
    out.println("<span class='input-icon' id='heightIcon'></span>");
    out.println("</div>");
    out.println("<div class='error-message' id='heightError'>Height must be between 50-250 cm</div>");
    out.println("</div>");
    
    out.println("<div class='form-group'>");
    out.println("<label class='label'>⚖️ Weight (kg):</label>");
    out.println("<div class='input-wrapper'>");
    out.println("<input type='number' name='weight' id='weightInput' class='input' placeholder='Enter weight (10-300 kg)' min='10' max='300' step='0.1' required>");
    out.println("<span class='input-icon' id='weightIcon'></span>");
    out.println("</div>");
    out.println("<div class='error-message' id='weightError'>Weight must be between 10-300 kg</div>");
    out.println("</div>");
    
    out.println("<button type='submit' class='btn-primary' id='calculateBtn'>📊 Calculate BMI</button>");
    out.println("</form>");
    
    out.println("<form method='get' action='Client'>");
    out.println("<button type='submit' class='btn-secondary'>← Back</button>");
    out.println("</form>");
    
    out.println("</div></body>");
    
    out.println("<script>");
    out.println("const heightInput = document.getElementById('heightInput');");
    out.println("const weightInput = document.getElementById('weightInput');");
    out.println("const heightIcon = document.getElementById('heightIcon');");
    out.println("const weightIcon = document.getElementById('weightIcon');");
    out.println("const heightError = document.getElementById('heightError');");
    out.println("const weightError = document.getElementById('weightError');");
    out.println("const calculateBtn = document.getElementById('calculateBtn');");
    
    out.println("function validateInput(input, icon, errorMsg, min, max) {");
    out.println("  const value = parseFloat(input.value);");
    out.println("  const isEmpty = input.value === '';");
    out.println("  const isValid = !isEmpty && !isNaN(value) && value >= min && value <= max;");
    
    out.println("  if (isEmpty) {");
    out.println("    icon.textContent = '';");
    out.println("    errorMsg.style.display = 'none';");
    out.println("    input.style.borderColor = '#e5e7eb';");
    out.println("  } else if (isValid) {");
    out.println("    icon.textContent = '✓';");
    out.println("    icon.className = 'input-icon valid-icon';");
    out.println("    errorMsg.style.display = 'none';");
    out.println("    input.style.borderColor = '#10b981';");
    out.println("  } else {");
    out.println("    icon.textContent = '✗';");
    out.println("    icon.className = 'input-icon invalid-icon';");
    out.println("    errorMsg.style.display = 'block';");
    out.println("    input.style.borderColor = '#ef4444';");
    out.println("    showErrorAlert(input, min, max);");
    out.println("  }");
    out.println("  updateSubmitButton();");
    out.println("}");
    
    out.println("function showErrorAlert(input, min, max) {");
    out.println("  const errorAlert = document.getElementById('errorAlert');");
    out.println("  const errorAlertText = document.getElementById('errorAlertText');");
    out.println("  const inputName = input.name;");
    out.println("  let message = '';");
    
    out.println("  if (inputName === 'height') {");
    out.println("    message = 'Height cannot exceed 250 cm!';");
    out.println("    if (parseFloat(input.value) < min) message = 'Height cannot be less than 50 cm!';");
    out.println("  } else if (inputName === 'weight') {");
    out.println("    message = 'Weight cannot exceed 300 kg!';");
    out.println("    if (parseFloat(input.value) < min) message = 'Weight cannot be less than 10 kg!';");
    out.println("  }");
    
    out.println("  errorAlertText.textContent = message;");
    out.println("  errorAlert.style.display = 'block';");
    out.println("  setTimeout(() => { errorAlert.style.display = 'none'; }, 5000);");
    out.println("}");
    
    out.println("function updateSubmitButton() {");
    out.println("  const heightValue = parseFloat(heightInput.value);");
    out.println("  const weightValue = parseFloat(weightInput.value);");
    out.println("  const heightValid = !isNaN(heightValue) && heightValue >= 50 && heightValue <= 250;");
    out.println("  const weightValid = !isNaN(weightValue) && weightValue >= 10 && weightValue <= 300;");
    out.println("  const bothFilled = heightInput.value !== '' && weightInput.value !== '';");
    
    out.println("  if (bothFilled && heightValid && weightValid) {");
    out.println("    calculateBtn.disabled = false;");
    out.println("    calculateBtn.style.opacity = '1';");
    out.println("  } else if (bothFilled && (!heightValid || !weightValid)) {");
    out.println("    calculateBtn.disabled = true;");
    out.println("    calculateBtn.style.opacity = '0.6';");
    out.println("  } else {");
    out.println("    calculateBtn.disabled = false;");
    out.println("    calculateBtn.style.opacity = '1';");
    out.println("  }");
    out.println("}");
    
    out.println("heightInput.addEventListener('input', function() {");
    out.println("  validateInput(this, heightIcon, heightError, 50, 250);");
    out.println("});");
    
    out.println("weightInput.addEventListener('input', function() {");
    out.println("  validateInput(this, weightIcon, weightError, 10, 300);");
    out.println("});");
    
    out.println("heightInput.addEventListener('blur', function() {");
    out.println("  validateInput(this, heightIcon, heightError, 50, 250);");
    out.println("});");
    
    out.println("weightInput.addEventListener('blur', function() {");
    out.println("  validateInput(this, weightIcon, weightError, 10, 300);");
    out.println("});");
    
    out.println("</script>");
    out.println("</html>");
}



     private void showCalorieBurnForm(PrintWriter out) {
    out.println("<!DOCTYPE html><html><head><title>Calorie Burn Calculator</title>");
    out.println("<style>");
    out.println("body { font-family: Arial, sans-serif; background: linear-gradient(135deg, #667eea, #764ba2); padding: 20px; color: #000; }");
    out.println(".container { max-width: 600px; margin: auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }");
    out.println("h2 { text-align: center; color: #6c63ff; margin-bottom: 25px; }");
    out.println(".form-group { margin-bottom: 20px; }");
    out.println("label { display: block; margin-bottom: 8px; font-weight: bold; }");
    out.println("input, select { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 5px; font-size: 15px; }");
    out.println("button { background-color: #6c63ff; color: white; padding: 12px 20px; border: none; border-radius: 8px; font-size: 16px; cursor: pointer; }");
    out.println("button:hover { background-color: #574fd6; }");
    out.println(".back-btn { background: #ccc; color: #333; margin-top: 20px; }");
    out.println(".back-btn:hover { background: #aaa; }");
    
    // ERROR MESSAGE STYLING
    out.println(".error-message { background: #ffebee; border: 2px solid #f44336; color: #c62828; padding: 15px; border-radius: 8px; margin: 15px 0; font-weight: bold; display: none; text-align: center; }");
    
    out.println("</style>");
    
    // JAVASCRIPT FOR VALIDATION
    out.println("<script>");
    
    // Age validation
    out.println("function validateAge(input) {");
    out.println("    let value = input.value;");
    out.println("    let errorMsg = document.getElementById('ageError');");
    out.println("    ");
    out.println("    value = value.replace(/[^0-9]/g, '');");
    out.println("    if (value.length > 3) {");
    out.println("        value = value.substring(0, 3);");
    out.println("    }");
    out.println("    input.value = value;");
    out.println("    ");
    out.println("    errorMsg.style.display = 'none';");
    out.println("    ");
    out.println("    if (value === '') return;");
    out.println("    ");
    out.println("    let age = parseInt(value);");
    out.println("    ");
    out.println("    if (age >= 100) {");
    out.println("        errorMsg.innerHTML = '🚫 Age cannot be 100 or above!';");
    out.println("        errorMsg.style.display = 'block';");
    out.println("    }");
    out.println("}");
    out.println("");
    
    // Height validation
    out.println("function validateHeight(input) {");
    out.println("    let value = input.value;");
    out.println("    let errorMsg = document.getElementById('heightError');");
    out.println("    ");
    out.println("    // Allow numbers and decimal point");
    out.println("    value = value.replace(/[^0-9.]/g, '');");
    out.println("    ");
    out.println("    // Prevent multiple decimal points");
    out.println("    let parts = value.split('.');");
    out.println("    if (parts.length > 2) {");
    out.println("        value = parts[0] + '.' + parts.slice(1).join('');");
    out.println("    }");
    out.println("    ");
    out.println("    // Limit to 3 digits before decimal");
    out.println("    if (parts[0].length > 3) {");
    out.println("        parts[0] = parts[0].substring(0, 3);");
    out.println("        value = parts.join('.');");
    out.println("    }");
    out.println("    ");
    out.println("    input.value = value;");
    out.println("    errorMsg.style.display = 'none';");
    out.println("    ");
    out.println("    if (value === '' || value === '.') return;");
    out.println("    ");
    out.println("    let height = parseFloat(value);");
    out.println("    ");
    out.println("    if (height < 100) {");
    out.println("        errorMsg.innerHTML = '📏 Height must be at least 100 cm!';");
    out.println("        errorMsg.style.display = 'block';");
    out.println("    } else if (height > 250) {");
    out.println("        errorMsg.innerHTML = '📏 Height cannot exceed 250 cm!';");
    out.println("        errorMsg.style.display = 'block';");
    out.println("    }");
    out.println("}");
    out.println("");
    
    // Weight validation
    out.println("function validateWeight(input) {");
    out.println("    let value = input.value;");
    out.println("    let errorMsg = document.getElementById('weightError');");
    out.println("    ");
    out.println("    // Allow numbers and decimal point");
    out.println("    value = value.replace(/[^0-9.]/g, '');");
    out.println("    ");
    out.println("    // Prevent multiple decimal points");
    out.println("    let parts = value.split('.');");
    out.println("    if (parts.length > 2) {");
    out.println("        value = parts[0] + '.' + parts.slice(1).join('');");
    out.println("    }");
    out.println("    ");
    out.println("    // Limit to 3 digits before decimal");
    out.println("    if (parts[0].length > 3) {");
    out.println("        parts[0] = parts[0].substring(0, 3);");
    out.println("        value = parts.join('.');");
    out.println("    }");
    out.println("    ");
    out.println("    input.value = value;");
    out.println("    errorMsg.style.display = 'none';");
    out.println("    ");
    out.println("    if (value === '' || value === '.') return;");
    out.println("    ");
    out.println("    let weight = parseFloat(value);");
    out.println("    ");
    out.println("    if (weight < 30) {");
    out.println("        errorMsg.innerHTML = '⚖️ Weight must be at least 30 kg!';");
    out.println("        errorMsg.style.display = 'block';");
    out.println("    } else if (weight > 200) {");
    out.println("        errorMsg.innerHTML = '⚖️ Weight cannot exceed 200 kg!';");
    out.println("        errorMsg.style.display = 'block';");
    out.println("    }");
    out.println("}");
    out.println("");
    
    // Form validation on submit
    out.println("function validateForm() {");
    out.println("    let ageInput = document.getElementById('age');");
    out.println("    let heightInput = document.getElementById('height');");
    out.println("    let weightInput = document.getElementById('weight');");
    out.println("    ");
    out.println("    let age = parseInt(ageInput.value);");
    out.println("    let height = parseFloat(heightInput.value);");
    out.println("    let weight = parseFloat(weightInput.value);");
    out.println("    ");
    out.println("    // Age validation");
    out.println("    if (age >= 100) {");
    out.println("        document.getElementById('ageError').innerHTML = '🚫 Please enter an age below 100!';");
    out.println("        document.getElementById('ageError').style.display = 'block';");
    out.println("        ageInput.focus();");
    out.println("        return false;");
    out.println("    }");
    out.println("    ");
    out.println("    // Height validation");
    out.println("    if (height < 100 || height > 250) {");
    out.println("        document.getElementById('heightError').innerHTML = '📏 Height must be between 100-250 cm!';");
    out.println("        document.getElementById('heightError').style.display = 'block';");
    out.println("        heightInput.focus();");
    out.println("        return false;");
    out.println("    }");
    out.println("    ");
    out.println("    // Weight validation");
    out.println("    if (weight < 30 || weight > 200) {");
    out.println("        document.getElementById('weightError').innerHTML = '⚖️ Weight must be between 30-200 kg!';");
    out.println("        document.getElementById('weightError').style.display = 'block';");
    out.println("        weightInput.focus();");
    out.println("        return false;");
    out.println("    }");
    out.println("    ");
    out.println("    return true;");
    out.println("}");
    out.println("</script>");
    
    out.println("</head><body>");
    out.println("<div class='container'>");
    out.println("<h2>🔥 Calorie Burn Calculator</h2>");
    
    // ERROR MESSAGE DIVS
    out.println("<div id='ageError' class='error-message'></div>");
    out.println("<div id='heightError' class='error-message'></div>");
    out.println("<div id='weightError' class='error-message'></div>");
    
    // FORM WITH VALIDATION
    out.println("<form method='post' onsubmit='return validateForm()'>");
    out.println("<input type='hidden' name='calculator' value='calorie'>");
    
    // Age input
    out.println("<div class='form-group'><label>🎂 Age:</label>");
    out.println("<input type='text' id='age' name='age' ");
    out.println("       oninput='validateAge(this)' ");
    out.println("       maxlength='3' ");
    out.println("       placeholder='Enter your age' ");
    out.println("       required></div>");
    
    // Gender select
    out.println("<div class='form-group'><label>🚻 Gender:</label>");
    out.println("<select name='gender' required>");
    out.println("<option value=''>Select Gender</option>");
    out.println("<option value='male'>Male</option>");
    out.println("<option value='female'>Female</option>");
    out.println("</select></div>");
    
    // Height input with validation
    out.println("<div class='form-group'><label>📏 Height (cm):</label>");
    out.println("<input type='text' id='height' name='height' ");
    out.println("       oninput='validateHeight(this)' ");
    out.println("       placeholder='Enter height (50-200 cm)' ");
    out.println("       required></div>");
    
    // Weight input with validation
    out.println("<div class='form-group'><label>⚖️ Weight (kg):</label>");
    out.println("<input type='text' id='weight' name='weight' ");
    out.println("       oninput='validateWeight(this)' ");
    out.println("       placeholder='Enter weight (10-200 kg)' ");
    out.println("       required></div>");
    
    // Activity level select
    out.println("<div class='form-group'><label>🏃‍♀️ Activity Level:</label>");
    out.println("<select name='activityLevel' required>");
    out.println("<option value=''>Select Activity Level</option>");
    out.println("<option value='sedentary'>Sedentary (little/no exercise)</option>");
    out.println("<option value='light'>Light (1-3 times/week)</option>");
    out.println("<option value='moderate'>Moderate (4-5 times/week)</option>");
    out.println("<option value='active'>Active (daily or 3-4x intense)</option>");
    out.println("<option value='very active'>Very Active (6-7 times/week)</option>");
    out.println("</select></div>");
    
    out.println("<button type='submit'>🔥 Calculate Calorie Burn</button>");
    out.println("</form>");
    out.println("<form method='get' action='Client'>");
    out.println("<button class='back-btn'>⬅ Back</button>");
    out.println("</form>");
    out.println("</div></body></html>");
}


     private void showBodyFatForm(PrintWriter out) {
    out.println("<!DOCTYPE html><html><head><title>Body Fat Calculator</title>");
    out.println("<style>");
    out.println("body { font-family: Arial, sans-serif; background: linear-gradient(135deg, #667eea, #764ba2); padding: 20px; color: #000; }");
    out.println(".container { max-width: 600px; margin: auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }");
    out.println("h2 { text-align: center; color: #6c63ff; margin-bottom: 25px; }");
    out.println(".form-group { margin-bottom: 20px; }");
    out.println("label { display: block; margin-bottom: 8px; font-weight: bold; color: #333; }");
    out.println("input, select { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 5px; font-size: 15px; }");
    out.println("button { background-color: #6c63ff; color: white; padding: 12px 20px; border: none; border-radius: 8px; font-size: 16px; cursor: pointer; }");
    out.println("button:hover { background-color: #574fd6; }");
    out.println(".back-btn { background: #ccc; color: #333; margin-top: 20px; }");
    out.println(".back-btn:hover { background: #aaa; }");
    
    // ERROR MESSAGE STYLING
    out.println(".error-message { background: #ffebee; border: 2px solid #f44336; color: #c62828; padding: 15px; border-radius: 8px; margin: 15px 0; font-weight: bold; display: none; text-align: center; }");
    
    out.println("</style>");
    
    // JAVASCRIPT FOR VALIDATION
    out.println("<script>");
    
    // Age validation
    out.println("function validateAge(input) {");
    out.println("    let value = input.value;");
    out.println("    let errorMsg = document.getElementById('ageError');");
    out.println("    ");
    out.println("    value = value.replace(/[^0-9]/g, '');");
    out.println("    if (value.length > 3) {");
    out.println("        value = value.substring(0, 3);");
    out.println("    }");
    out.println("    input.value = value;");
    out.println("    ");
    out.println("    errorMsg.style.display = 'none';");
    out.println("    ");
    out.println("    if (value === '') return;");
    out.println("    ");
    out.println("    let age = parseInt(value);");
    out.println("    ");
    out.println("    if (age < 13) {");
    out.println("        errorMsg.innerHTML = '🎂 Age must be at least 13 years old!';");
    out.println("        errorMsg.style.display = 'block';");
    out.println("    } else if (age > 80) {");
    out.println("        errorMsg.innerHTML = '🎂 Age cannot exceed 80 years!';");
    out.println("        errorMsg.style.display = 'block';");
    out.println("    }");
    out.println("}");
    out.println("");
    
    // Weight validation
    out.println("function validateWeight(input) {");
    out.println("    let value = input.value;");
    out.println("    let errorMsg = document.getElementById('weightError');");
    out.println("    ");
    out.println("    value = value.replace(/[^0-9.]/g, '');");
    out.println("    let parts = value.split('.');");
    out.println("    if (parts.length > 2) {");
    out.println("        value = parts[0] + '.' + parts.slice(1).join('');");
    out.println("    }");
    out.println("    if (parts[0].length > 3) {");
    out.println("        parts[0] = parts[0].substring(0, 3);");
    out.println("        value = parts.join('.');");
    out.println("    }");
    out.println("    input.value = value;");
    out.println("    errorMsg.style.display = 'none';");
    out.println("    ");
    out.println("    if (value === '' || value === '.') return;");
    out.println("    ");
    out.println("    let weight = parseFloat(value);");
    out.println("    ");
    out.println("    if (weight < 30) {");
    out.println("        errorMsg.innerHTML = '⚖️ Weight must be at least 30 kg!';");
    out.println("        errorMsg.style.display = 'block';");
    out.println("    } else if (weight > 200) {");
    out.println("        errorMsg.innerHTML = '⚖️ Weight cannot exceed 200 kg!';");
    out.println("        errorMsg.style.display = 'block';");
    out.println("    }");
    out.println("}");
    out.println("");
    
    // Height validation
    out.println("function validateHeight(input) {");
    out.println("    let value = input.value;");
    out.println("    let errorMsg = document.getElementById('heightError');");
    out.println("    ");
    out.println("    value = value.replace(/[^0-9.]/g, '');");
    out.println("    let parts = value.split('.');");
    out.println("    if (parts.length > 2) {");
    out.println("        value = parts[0] + '.' + parts.slice(1).join('');");
    out.println("    }");
    out.println("    if (parts[0].length > 3) {");
    out.println("        parts[0] = parts[0].substring(0, 3);");
    out.println("        value = parts.join('.');");
    out.println("    }");
    out.println("    input.value = value;");
    out.println("    errorMsg.style.display = 'none';");
    out.println("    ");
    out.println("    if (value === '' || value === '.') return;");
    out.println("    ");
    out.println("    let height = parseFloat(value);");
    out.println("    ");
    out.println("    if (height < 100) {");
    out.println("        errorMsg.innerHTML = '📏 Height must be at least 100 cm!';");
    out.println("        errorMsg.style.display = 'block';");
    out.println("    } else if (height > 250) {");
    out.println("        errorMsg.innerHTML = '📏 Height cannot exceed 250 cm!';");
    out.println("        errorMsg.style.display = 'block';");
    out.println("    }");
    out.println("}");
    out.println("");
    
    // Neck validation
    out.println("function validateNeck(input) {");
    out.println("    let value = input.value;");
    out.println("    let errorMsg = document.getElementById('neckError');");
    out.println("    ");
    out.println("    value = value.replace(/[^0-9.]/g, '');");
    out.println("    let parts = value.split('.');");
    out.println("    if (parts.length > 2) {");
    out.println("        value = parts[0] + '.' + parts.slice(1).join('');");
    out.println("    }");
    out.println("    if (parts[0].length > 2) {");
    out.println("        parts[0] = parts[0].substring(0, 2);");
    out.println("        value = parts.join('.');");
    out.println("    }");
    out.println("    input.value = value;");
    out.println("    errorMsg.style.display = 'none';");
    out.println("    ");
    out.println("    if (value === '' || value === '.') return;");
    out.println("    ");
    out.println("    let neck = parseFloat(value);");
    out.println("    ");
    out.println("    if (neck < 25) {");
    out.println("        errorMsg.innerHTML = '👔 Neck must be at least 25 cm!';");
    out.println("        errorMsg.style.display = 'block';");
    out.println("    } else if (neck > 60) {");
    out.println("        errorMsg.innerHTML = '👔 Neck cannot exceed 60 cm!';");
    out.println("        errorMsg.style.display = 'block';");
    out.println("    }");
    out.println("}");
    out.println("");
    
    // Waist validation
    out.println("function validateWaist(input) {");
    out.println("    let value = input.value;");
    out.println("    let errorMsg = document.getElementById('waistError');");
    out.println("    ");
    out.println("    value = value.replace(/[^0-9.]/g, '');");
    out.println("    let parts = value.split('.');");
    out.println("    if (parts.length > 2) {");
    out.println("        value = parts[0] + '.' + parts.slice(1).join('');");
    out.println("    }");
    out.println("    if (parts[0].length > 3) {");
    out.println("        parts[0] = parts[0].substring(0, 3);");
    out.println("        value = parts.join('.');");
    out.println("    }");
    out.println("    input.value = value;");
    out.println("    errorMsg.style.display = 'none';");
    out.println("    ");
    out.println("    if (value === '' || value === '.') return;");
    out.println("    ");
    out.println("    let waist = parseFloat(value);");
    out.println("    ");
    out.println("    if (waist < 50) {");
    out.println("        errorMsg.innerHTML = '👖 Waist must be at least 50 cm!';");
    out.println("        errorMsg.style.display = 'block';");
    out.println("    } else if (waist > 150) {");
    out.println("        errorMsg.innerHTML = '👖 Waist cannot exceed 150 cm!';");
    out.println("        errorMsg.style.display = 'block';");
    out.println("    }");
    out.println("}");
    out.println("");
    
    // Hip validation
    out.println("function validateHip(input) {");
    out.println("    let value = input.value;");
    out.println("    let errorMsg = document.getElementById('hipError');");
    out.println("    ");
    out.println("    value = value.replace(/[^0-9.]/g, '');");
    out.println("    let parts = value.split('.');");
    out.println("    if (parts.length > 2) {");
    out.println("        value = parts[0] + '.' + parts.slice(1).join('');");
    out.println("    }");
    out.println("    if (parts[0].length > 3) {");
    out.println("        parts[0] = parts[0].substring(0, 3);");
    out.println("        value = parts.join('.');");
    out.println("    }");
    out.println("    input.value = value;");
    out.println("    errorMsg.style.display = 'none';");
    out.println("    ");
    out.println("    if (value === '' || value === '.') return;");
    out.println("    ");
    out.println("    let hip = parseFloat(value);");
    out.println("    ");
    out.println("    if (hip < 60) {");
    out.println("        errorMsg.innerHTML = '👗 Hip must be at least 60 cm!';");
    out.println("        errorMsg.style.display = 'block';");
    out.println("    } else if (hip > 160) {");
    out.println("        errorMsg.innerHTML = '👗 Hip cannot exceed 160 cm!';");
    out.println("        errorMsg.style.display = 'block';");
    out.println("    }");
    out.println("}");
    out.println("");
    
    // Toggle hip field function
    out.println("function toggleHipField() {");
    out.println("    var gender = document.getElementById('gender').value;");
    out.println("    var hipGroup = document.getElementById('hipGroup');");
    out.println("    var hipInput = document.getElementById('hip');");
    out.println("    var hipError = document.getElementById('hipError');");
    out.println("    ");
    out.println("    if (gender === 'female') {");
    out.println("        hipGroup.style.display = 'block';");
    out.println("        hipInput.required = true;");
    out.println("    } else {");
    out.println("        hipGroup.style.display = 'none';");
    out.println("        hipInput.required = false;");
    out.println("        hipInput.value = '';");
    out.println("        hipError.style.display = 'none';");
    out.println("    }");
    out.println("}");
    out.println("");
    
    // Form validation
    out.println("function validateForm() {");
    out.println("    let age = parseInt(document.getElementById('age').value);");
    out.println("    let weight = parseFloat(document.getElementById('weight').value);");
    out.println("    let height = parseFloat(document.getElementById('height').value);");
    out.println("    let neck = parseFloat(document.getElementById('neck').value);");
    out.println("    let waist = parseFloat(document.getElementById('waist').value);");
    out.println("    let gender = document.getElementById('gender').value;");
    out.println("    ");
    out.println("    // Age validation");
    out.println("    if (age < 13 || age > 80) {");
    out.println("        document.getElementById('ageError').innerHTML = '🎂 Age must be between 13-80 years!';");
    out.println("        document.getElementById('ageError').style.display = 'block';");
    out.println("        document.getElementById('age').focus();");
    out.println("        return false;");
    out.println("    }");
    out.println("    ");
    out.println("    // Weight validation");
    out.println("    if (weight < 30 || weight > 200) {");
    out.println("        document.getElementById('weightError').innerHTML = '⚖️ Weight must be between 30-200 kg!';");
    out.println("        document.getElementById('weightError').style.display = 'block';");
    out.println("        document.getElementById('weight').focus();");
    out.println("        return false;");
    out.println("    }");
    out.println("    ");
    out.println("    // Height validation");
    out.println("    if (height < 100 || height > 250) {");
    out.println("        document.getElementById('heightError').innerHTML = '📏 Height must be between 100-250 cm!';");
    out.println("        document.getElementById('heightError').style.display = 'block';");
    out.println("        document.getElementById('height').focus();");
    out.println("        return false;");
    out.println("    }");
    out.println("    ");
    out.println("    // Neck validation");
    out.println("    if (neck < 25 || neck > 60) {");
    out.println("        document.getElementById('neckError').innerHTML = '👔 Neck must be between 25-60 cm!';");
    out.println("        document.getElementById('neckError').style.display = 'block';");
    out.println("        document.getElementById('neck').focus();");
    out.println("        return false;");
    out.println("    }");
    out.println("    ");
    out.println("    // Waist validation");
    out.println("    if (waist < 50 || waist > 150) {");
    out.println("        document.getElementById('waistError').innerHTML = '👖 Waist must be between 50-150 cm!';");
    out.println("        document.getElementById('waistError').style.display = 'block';");
    out.println("        document.getElementById('waist').focus();");
    out.println("        return false;");
    out.println("    }");
    out.println("    ");
    out.println("    // Hip validation for females");
    out.println("    if (gender === 'female') {");
    out.println("        let hip = parseFloat(document.getElementById('hip').value);");
    out.println("        if (hip < 60 || hip > 160) {");
    out.println("            document.getElementById('hipError').innerHTML = '👗 Hip must be between 60-160 cm!';");
    out.println("            document.getElementById('hipError').style.display = 'block';");
    out.println("            document.getElementById('hip').focus();");
    out.println("            return false;");
    out.println("        }");
    out.println("    }");
    out.println("    ");
    out.println("    return true;");
    out.println("}");
    out.println("</script>");
    
    out.println("</head><body>");
    out.println("<div class='container'>");
    out.println("<h2>📉 Body Fat Calculator 💪</h2>");
    
    // ERROR MESSAGE DIVS
    out.println("<div id='ageError' class='error-message'></div>");
    out.println("<div id='weightError' class='error-message'></div>");
    out.println("<div id='heightError' class='error-message'></div>");
    out.println("<div id='neckError' class='error-message'></div>");
    out.println("<div id='waistError' class='error-message'></div>");
    out.println("<div id='hipError' class='error-message'></div>");
    
    out.println("<form method='post' action='Client' onsubmit='return validateForm()'>");
    out.println("<input type='hidden' name='calculator' value='bodyfat'>");

    out.println("<div class='form-group'>");
    out.println("<label>🚻 Gender:</label>");
    out.println("<select name='gender' id='gender' required onchange='toggleHipField()'>");
    out.println("<option value=''>-- Select Gender --</option>");
    out.println("<option value='male'>Male</option>");
    out.println("<option value='female'>Female</option>");
    out.println("</select>");
    out.println("</div>");

    out.println("<div class='form-group'><label>🎂 Age:</label>");
    out.println("<input type='text' id='age' name='age' oninput='validateAge(this)' maxlength='2' placeholder='13-80 years' required></div>");

    out.println("<div class='form-group'><label>⚖️ Weight (kg):</label>");
    out.println("<input type='text' id='weight' name='weight' oninput='validateWeight(this)' placeholder='30-200 kg' required></div>");

    out.println("<div class='form-group'><label>📏 Height (cm):</label>");
    out.println("<input type='text' id='height' name='height' oninput='validateHeight(this)' placeholder='100-250 cm' required></div>");

    out.println("<div class='form-group'><label>👔 Neck (cm):</label>");
    out.println("<input type='text' id='neck' name='neck' oninput='validateNeck(this)' placeholder='25-60 cm' required></div>");

    out.println("<div class='form-group'><label>👖 Waist (cm):</label>");
    out.println("<input type='text' id='waist' name='waist' oninput='validateWaist(this)' placeholder='50-150 cm' required></div>");

    out.println("<div class='form-group' id='hipGroup' style='display: none;'>");
    out.println("<label>👗 Hip (cm):</label>");
    out.println("<input type='text' name='hip' id='hip' oninput='validateHip(this)' placeholder='60-160 cm'></div>");

    out.println("<button type='submit'>🔢 Calculate Body Fat</button>");
    out.println("</form>");

    out.println("<form method='get' action='Client'>");
    out.println("<button class='back-btn'>⬅ Back</button>");
    out.println("</form>");

    out.println("</div>");
    out.println("</body></html>");
}



    private void showSleepForm(PrintWriter out) {
    out.println("<!DOCTYPE html>");
    out.println("<html><head><title>😴 Sleep Recommendation</title>");
    out.println("<style>");
    out.println("body { font-family: Arial, sans-serif; background: linear-gradient(135deg, #667eea, #764ba2); padding: 20px; color: #000; }");
    out.println(".container { max-width: 500px; margin: auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); text-align: center; }");
    out.println(".form-group { margin-bottom: 20px; text-align: left; }");
    out.println("label { display: block; margin-bottom: 8px; font-weight: bold; font-size: 16px; color: #000; }");
    out.println("input[type='number'] { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 5px; font-size: 16px; }");
    out.println("button { background-color: #6c63ff; color: white; padding: 12px 20px; border: none; border-radius: 8px; font-size: 16px; cursor: pointer; }");
    out.println("button:hover { background-color: #574fd6; }");
    out.println("h2 { margin-bottom: 25px; font-size: 24px; color: #6c63ff; }");
    out.println(".back-btn { background: #ccc; color: #333; margin-top: 20px; }");
    out.println(".back-btn:hover { background: #aaa; }");
    
    // TAMBAH CSS UNTUK ERROR MESSAGE
    out.println(".error-message { background: #ffebee; border: 2px solid #f44336; color: #c62828; padding: 15px; border-radius: 8px; margin: 15px 0; font-weight: bold; display: none; text-align: center; }");
    out.println(".success-message { background: #e8f5e8; border: 2px solid #4caf50; color: #2e7d32; padding: 15px; border-radius: 8px; margin: 15px 0; font-weight: bold; display: none; text-align: center; }");
    
    out.println("</style>");
    
    // TAMBAH JAVASCRIPT UNTUK VALIDASI
    out.println("<script>");
    out.println("function validateAge(input) {");
    out.println("    let value = input.value;");
    out.println("    let errorMsg = document.getElementById('ageError');");
    out.println("    let successMsg = document.getElementById('ageSuccess');");
    out.println("    ");
    out.println("    // Only allow numbers and limit to 3 digits");
    out.println("    value = value.replace(/[^0-9]/g, '');");
    out.println("    if (value.length > 3) {");
    out.println("        value = value.substring(0, 3);");
    out.println("    }");
    out.println("    input.value = value;");
    out.println("    ");
    out.println("    // Reset messages");
    out.println("    errorMsg.style.display = 'none';");
    out.println("    successMsg.style.display = 'none';");
    out.println("    ");
    out.println("    if (value === '') return;");
    out.println("    ");
    out.println("    let age = parseInt(value);");
    out.println("    ");
    out.println("    if (age > 100) {");
    out.println("        errorMsg.innerHTML = '🚫 Age cannot exceed 100 years!';");
    out.println("        errorMsg.style.display = 'block';");
    out.println("        input.value = '100';");
    out.println("        setTimeout(() => {");
    out.println("            errorMsg.style.display = 'none';");
    out.println("            successMsg.innerHTML = '✅ Age adjusted to 100';");
    out.println("            successMsg.style.display = 'block';");
    out.println("        }, 2000);");
    out.println("    } else if (age < 1) {");
    out.println("        errorMsg.innerHTML = '🚫 Age must be at least 1 year!';");
    out.println("        errorMsg.style.display = 'block';");
    out.println("        input.value = '1';");
    out.println("        setTimeout(() => {");
    out.println("            errorMsg.style.display = 'none';");
    out.println("            successMsg.innerHTML = '✅ Age adjusted to 1';");
    out.println("            successMsg.style.display = 'block';");
    out.println("        }, 2000);");
    out.println("    } else {");
    out.println("        successMsg.innerHTML = '✅ Valid age: ' + age + ' years old';");
    out.println("        successMsg.style.display = 'block';");
    out.println("    }");
    out.println("}");
    out.println("");
    out.println("// Validate on form submit");
    out.println("function validateForm() {");
    out.println("    let ageInput = document.getElementById('age');");
    out.println("    let age = parseInt(ageInput.value);");
    out.println("    ");
    out.println("    if (isNaN(age) || age < 1 || age > 100) {");
    out.println("        document.getElementById('ageError').innerHTML = '🚫 Please enter a valid age between 1 and 100!';");;
    out.println("        document.getElementById('ageError').style.display = 'block';");
    out.println("        ageInput.focus();");
    out.println("        return false;");
    out.println("    }");
    out.println("    return true;");
    out.println("}");
    out.println("</script>");
    
    out.println("</head><body>");
    out.println("<div class='container'>");
    out.println("<h2>🌙 Sleep Recommendation 😴</h2>");
    
    // TAMBAH DIV UNTUK MESEJ ERROR DAN SUCCESS
    out.println("<div id='ageError' class='error-message'></div>");
    out.println("<div id='ageSuccess' class='success-message'></div>");
    
    // UBAH FORM DENGAN VALIDASI
    out.println("<form method='post' onsubmit='return validateForm()'>");
    out.println("<input type='hidden' name='calculator' value='sleep'>");
    out.println("<div class='form-group'>");
    out.println("<label for='age'>🧒 Age:</label>");
    out.println("<input type='text' id='age' name='age' ");
    out.println("       oninput='validateAge(this)' ");
    out.println("       maxlength='3' ");
    out.println("       placeholder='Enter your age (1-100)' ");
    out.println("       required>");
    out.println("</div>");
    out.println("<button type='submit'>Get Recommendation</button>");
    out.println("</form>");
    out.println("<form method='get' action='Client'>");
    out.println("<button class='back-btn'>⬅ Back</button>");
    out.println("</form>");
    out.println("</div>");
    out.println("</body></html>");
}



    private void showCycleForm(PrintWriter out) {
    out.println("<!DOCTYPE html>");
    out.println("<html><head><title>🌸 Menstrual Cycle Predictor</title>");
    out.println("<style>");
    out.println("body { font-family: Arial, sans-serif; background: linear-gradient(135deg, #667eea, #764ba2); padding: 20px; color: #000; }");
    out.println(".container { max-width: 500px; margin: auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); text-align: center; }");
    out.println(".form-group { margin-bottom: 20px; text-align: left; }");
    out.println("label { display: block; margin-bottom: 8px; font-weight: bold; font-size: 16px; color: #000; }");
    out.println("input[type='date'] { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 5px; font-size: 16px; }");
    out.println("button { background-color: #e86aa3; color: white; padding: 12px 20px; border: none; border-radius: 8px; font-size: 16px; cursor: pointer; }");
    out.println("button:hover { background-color: #d94f92; }");
    out.println("h2 { margin-bottom: 25px; font-size: 24px; color: #black; }");
    out.println(".back-btn { background: #ccc; color: #333; margin-top: 20px; margin:center;}");
    out.println(".back-btn:hover { background: #aaa; }");
    out.println("</style></head><body>");

    out.println("<div class='container'>");
    out.println("<h2>🌸 Menstrual Cycle Predictor 🌸</h2>");
    out.println("<form method='post'>");
    out.println("<input type='hidden' name='calculator' value='cycle'>");

    out.println("<div class='form-group'>");
    out.println("<label for='lastDate'>🌷 Start Date:</label>");
    out.println("<input type='date' id='lastDate' name='lastDate' required>");
    out.println("</div>");

    out.println("<div class='form-group'>");
    out.println("<label for='endDate'>🌺 End Date:</label>");
    out.println("<input type='date' id='endDate' name='endDate' required>");
    out.println("</div>");

    out.println("<button type='submit'>🔮 Predict</button>");
    out.println("</form>");

    out.println("<form method='get' action='Client'>");
    out.println("<button class='back-btn'>⬅ Back</button>");
    out.println("</form>");

    out.println("</div>");
    out.println("</body></html>");
}



     private void showAgeForm(PrintWriter out) {
    out.println("<!DOCTYPE html><html><head><title>Age Calculator</title>");
    out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
    out.println("<style>");
    out.println("* { margin: 0; padding: 0; box-sizing: border-box; }");
    out.println("body, html { height: 100%; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }");
    out.println(".container { display: flex; justify-content: center; align-items: center; min-height: 100vh; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 20px; }");
    out.println(".form-card { background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(10px); padding: 40px 32px; border-radius: 24px; width: 100%; max-width: 420px; text-align: center; box-shadow: 0 20px 40px rgba(0,0,0,0.15); position: relative; overflow: hidden; }");
    out.println(".form-card::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 4px; background: linear-gradient(90deg, #667eea, #764ba2); }");
    out.println(".header { margin-bottom: 32px; }");
    out.println(".form-card h2 { color: #2d3748; margin-bottom: 8px; font-size: 28px; font-weight: 600; display: flex; align-items: center; justify-content: center; gap: 12px; }");
    out.println(".form-card p { color: #718096; font-size: 16px; line-height: 1.5; }");
    out.println(".form-group { margin-bottom: 24px; text-align: left; position: relative; }");
    out.println(".form-group label { display: block; margin-bottom: 8px; color: #374151; font-weight: 500; font-size: 16px; }");
    out.println(".input-wrapper { position: relative; }");
    out.println(".form-group input { width: 100%; padding: 16px 20px; border: 2px solid #e5e7eb; border-radius: 12px; font-size: 16px; background: white; transition: all 0.3s ease; outline: none; }");
    out.println(".form-group input:focus { border-color: #667eea; box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1); transform: translateY(-1px); }");
    out.println(".form-group input.valid { border-color: #10b981; }");
    out.println(".form-group input.invalid { border-color: #ef4444; }");
    out.println(".input-icon { position: absolute; right: 16px; top: 50%; transform: translateY(-50%); font-size: 18px; }");
    out.println(".valid-icon { color: #10b981; }");
    out.println(".invalid-icon { color: #ef4444; }");
    
    // Enhanced error and success message styling
    out.println(".error-message { color: #dc2626; font-size: 14px; margin-top: 8px; display: none; background: #fef2f2; padding: 10px 14px; border-radius: 8px; border: 1px solid #fecaca; border-left: 4px solid #dc2626; }");
    out.println(".success-message { color: #059669; font-size: 14px; margin-top: 8px; display: none; background: #f0fdf4; padding: 10px 14px; border-radius: 8px; border: 1px solid #bbf7d0; border-left: 4px solid #059669; }");
    out.println(".warning-message { color: #d97706; font-size: 14px; margin-top: 8px; display: none; background: #fffbeb; padding: 10px 14px; border-radius: 8px; border: 1px solid #fed7aa; border-left: 4px solid #d97706; }");
    
    out.println(".ic-format { font-size: 12px; color: #9ca3af; margin-top: 4px; }");
    out.println(".buttons { display: flex; gap: 12px; margin-top: 32px; }");
    out.println(".calculate-btn { flex: 2; background: linear-gradient(135deg, #667eea, #764ba2); color: white; border: none; padding: 18px 24px; border-radius: 12px; font-weight: 600; font-size: 16px; cursor: pointer; transition: all 0.3s ease; position: relative; overflow: hidden; }");
    out.println(".calculate-btn:hover:not(:disabled) { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4); }");
    out.println(".calculate-btn:disabled { opacity: 0.6; cursor: not-allowed; transform: none; background: #9ca3af; }");
    out.println(".back-btn { flex: 1; background: #f8fafc; color: #64748b; border: 2px solid #e2e8f0; padding: 16px 20px; border-radius: 12px; font-weight: 500; font-size: 16px; cursor: pointer; transition: all 0.3s ease; }");
    out.println(".back-btn:hover { background: #f1f5f9; border-color: #cbd5e1; transform: translateY(-1px); }");
    out.println(".loading { display: none; }");
    out.println(".calculate-btn.loading .loading { display: inline; }");
    out.println(".calculate-btn.loading .btn-text { display: none; }");
    out.println("@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }");
    out.println(".spinner { animation: spin 1s linear infinite; }");
    
    // Enhanced validation states
    out.println(".validation-container { position: relative; }");
    out.println(".char-counter { position: absolute; right: 8px; bottom: -20px; font-size: 11px; color: #9ca3af; }");
    out.println(".char-counter.warning { color: #f59e0b; }");
    out.println(".char-counter.error { color: #ef4444; }");
    
    out.println("@media (max-width: 480px) { .form-card { padding: 32px 24px; } .buttons { flex-direction: column; } .back-btn { order: 2; } }");
    out.println("</style></head><body>");
    
    out.println("<div class='container'>");
    out.println("<div class='form-card'>");
    out.println("<div class='header'>");
    out.println("<h2>🎂 Age Calculator</h2>");
    out.println("<p>Calculate your age from Malaysian IC number</p>");
    out.println("</div>");
    
    out.println("<form method='post' id='ageForm'>");
    out.println("<input type='hidden' name='calculator' value='age'>");
    out.println("<div class='form-group'>");
    out.println("<label>🆔 IC Number:</label>");
    out.println("<div class='input-wrapper validation-container'>");
    out.println("<input type='text' name='ic' id='icInput' placeholder='030908030332' required maxlength='12' pattern='[0-9]{12}'>");
    out.println("<span class='input-icon' id='validationIcon'></span>");
    out.println("<span class='char-counter' id='charCounter'>0/12</span>");
    out.println("</div>");
    out.println("<div class='ic-format'>Format: YYMMDDPBXXXX (12 digits)</div>");
    out.println("<div class='error-message' id='errorMessage'>❌ Please enter a valid 12-digit IC number</div>");
    out.println("<div class='success-message' id='successMessage'>✅ Valid IC number format</div>");
    out.println("<div class='warning-message' id='warningMessage'>⚠️ IC number must be exactly 12 digits</div>");
    out.println("</div>");
    
    out.println("<div class='buttons'>");
    out.println("<button type='submit' class='calculate-btn' id='calculateBtn' disabled>");
    out.println("<span class='btn-text'>🧮 CALCULATE AGE</span>");
    out.println("<span class='loading spinner'>⏳</span>");
    out.println("</button>");
    out.println("<button type='button' class='back-btn' onclick='history.back()'>← Back</button>");
    out.println("</div>");
    out.println("</form>");
    out.println("</div>");
    out.println("</div>");
    
    out.println("<script>");
    out.println("const icInput = document.getElementById('icInput');");
    out.println("const validationIcon = document.getElementById('validationIcon');");
    out.println("const errorMessage = document.getElementById('errorMessage');");
    out.println("const successMessage = document.getElementById('successMessage');");
    out.println("const warningMessage = document.getElementById('warningMessage');");
    out.println("const calculateBtn = document.getElementById('calculateBtn');");
    out.println("const charCounter = document.getElementById('charCounter');");
    out.println("const form = document.getElementById('ageForm');");
    
    // Enhanced input formatting and validation
    out.println("icInput.addEventListener('input', function(e) {");
    out.println("  let value = e.target.value.replace(/\\D/g, '');");
    out.println("  if (value.length > 12) value = value.substring(0, 12);");
    out.println("  e.target.value = value;");
    out.println("  updateCharCounter(value.length);");
    out.println("  validateIC(value);");
    out.println("});");
    
    // Character counter function
    out.println("function updateCharCounter(length) {");
    out.println("  charCounter.textContent = length + '/12';");
    out.println("  charCounter.className = 'char-counter';");
    out.println("  if (length > 12) {");
    out.println("    charCounter.classList.add('error');");
    out.println("  } else if (length > 8) {");
    out.println("    charCounter.classList.add('warning');");
    out.println("  }");
    out.println("}");
    
    // Enhanced validation function
    out.println("function validateIC(ic) {");
    out.println("  hideAllMessages();");
    out.println("  ");
    out.println("  if (ic.length === 0) {");
    out.println("    resetValidation();");
    out.println("    return;");
    out.println("  }");
    out.println("  ");
    out.println("  if (ic.length < 12) {");
    out.println("    showWarning();");
    out.println("    return;");
    out.println("  }");
    out.println("  ");
    out.println("  if (ic.length === 12) {");
    out.println("    if (!/^[0-9]{12}$/.test(ic)) {");
    out.println("      showError('IC number must contain only digits');");
    out.println("      return;");
    out.println("    }");
    out.println("    ");
    out.println("    if (!isValidDate(ic)) {");
    out.println("      showError('Invalid birth date in IC number');");
    out.println("      return;");
    out.println("    }");
    out.println("    ");
    out.println("    if (!isValidStateCode(ic)) {");
    out.println("      showError('Invalid state code in IC number');");
    out.println("      return;");
    out.println("    }");
    out.println("    ");
    out.println("    showSuccess();");
    out.println("  }");
    out.println("}");
    
    // Message display functions
    out.println("function hideAllMessages() {");
    out.println("  errorMessage.style.display = 'none';");
    out.println("  successMessage.style.display = 'none';");
    out.println("  warningMessage.style.display = 'none';");
    out.println("}");
    
    out.println("function resetValidation() {");
    out.println("  icInput.className = '';");
    out.println("  validationIcon.textContent = '';");
    out.println("  calculateBtn.disabled = true;");
    out.println("}");
    
    out.println("function showWarning() {");
    out.println("  icInput.className = '';");
    out.println("  validationIcon.textContent = '⚠️';");
    out.println("  validationIcon.className = 'input-icon';");
    out.println("  warningMessage.style.display = 'block';");
    out.println("  calculateBtn.disabled = true;");
    out.println("}");
    
    out.println("function showError(message) {");
    out.println("  icInput.className = 'invalid';");
    out.println("  validationIcon.textContent = '❌';");
    out.println("  validationIcon.className = 'input-icon invalid-icon';");
    out.println("  errorMessage.textContent = '❌ ' + message;");
    out.println("  errorMessage.style.display = 'block';");
    out.println("  calculateBtn.disabled = true;");
    out.println("}");
    
    out.println("function showSuccess() {");
    out.println("  icInput.className = 'valid';");
    out.println("  validationIcon.textContent = '✅';");
    out.println("  validationIcon.className = 'input-icon valid-icon';");
    out.println("  successMessage.style.display = 'block';");
    out.println("  calculateBtn.disabled = false;");
    out.println("}");
    
    // Enhanced date validation for IC
    out.println("function isValidDate(ic) {");
    out.println("  if (ic.length < 6) return false;");
    out.println("  const year = parseInt(ic.substring(0, 2));");
    out.println("  const month = parseInt(ic.substring(2, 4));");
    out.println("  const day = parseInt(ic.substring(4, 6));");
    out.println("  ");
    out.println("  // Determine full year (assuming cutoff at 30 for 2000s)");
    out.println("  const fullYear = year <= 30 ? 2000 + year : 1900 + year;");
    out.println("  ");
    out.println("  // Basic month and day validation");
    out.println("  if (month < 1 || month > 12) return false;");
    out.println("  if (day < 1 || day > 31) return false;");
    out.println("  ");
    out.println("  // Create date and validate");
    out.println("  const date = new Date(fullYear, month - 1, day);");
    out.println("  const isValidDate = date.getFullYear() === fullYear && ");
    out.println("                      date.getMonth() === month - 1 && ");
    out.println("                      date.getDate() === day;");
    out.println("  ");
    out.println("  // Check if date is not in the future");
    out.println("  const today = new Date();");
    out.println("  return isValidDate && date <= today;");
    out.println("}");
    
    // State code validation for Malaysian IC
    out.println("function isValidStateCode(ic) {");
    out.println("  if (ic.length < 8) return false;");
    out.println("  const stateCode = ic.substring(6, 8);");
    out.println("  const validCodes = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', ");
    out.println("                     '11', '12', '13', '14', '15', '16', '21', '22', '23', '24', ");
    out.println("                     '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', ");
    out.println("                     '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', ");
    out.println("                     '45', '46', '47', '48', '49', '50', '51', '52', '53', '54', ");
    out.println("                     '55', '56', '57', '58', '59', '60', '61', '62', '63', '64', ");
    out.println("                     '65', '66', '67', '68', '69', '70', '71', '72', '73', '74', ");
    out.println("                     '75', '76', '77', '78', '79', '80', '81', '82', '83', '97', '98', '99'];");
    out.println("  return validCodes.includes(stateCode);");
    out.println("}");
    
    // Form submission with loading state
    out.println("form.addEventListener('submit', function(e) {");
    out.println("  if (calculateBtn.disabled) {");
    out.println("    e.preventDefault();");
    out.println("    return false;");
    out.println("  }");
    out.println("  calculateBtn.classList.add('loading');");
    out.println("  calculateBtn.disabled = true;");
    out.println("});");
    
    // Initialize validation on page load
    out.println("document.addEventListener('DOMContentLoaded', function() {");
    out.println("  calculateBtn.disabled = true;");
    out.println("});");
    
    out.println("</script>");
    out.println("</body></html>");
}



    // UI DESIGN PROFILE SUMMARY
private void calculateUserInfo(HttpServletRequest request, PrintWriter out) {
    String name = request.getParameter("name");
    int age = Integer.parseInt(request.getParameter("age"));
    String gender = request.getParameter("gender");
    double height = Double.parseDouble(request.getParameter("height"));
    double weight = Double.parseDouble(request.getParameter("weight"));
    double bmi = weight / Math.pow(height / 100, 2);
    String category = (bmi < 18.5) ? "Underweight" : (bmi < 25) ? "Normal" : (bmi < 30) ? "Overweight" : "Obese";
    
    // Get category color
    String categoryColor = getCategoryColor(category);
    
    // Start HTML output with enhanced styling
    out.println("<!DOCTYPE html>");
    out.println("<html lang='en'>");
    out.println("<head>");
    out.println("<meta charset='UTF-8'>");
    out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
    out.println("<title>Profile Summary - Health Calculator</title>");
    out.println("<style>");
    out.println("* { margin: 0; padding: 0; box-sizing: border-box; }");
    out.println("body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; }");
    
    // Profile Card Styles
    out.println(".profile-card { background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(10px); border-radius: 20px; padding: 40px; box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1); border: 1px solid rgba(255, 255, 255, 0.2); max-width: 400px; width: 100%; position: relative; overflow: hidden; }");
    out.println(".profile-card::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 4px; background: linear-gradient(90deg, #667eea, #764ba2, #f093fb); background-size: 200% 100%; animation: shimmer 3s linear infinite; }");
    out.println("@keyframes shimmer { 0% { background-position: -200% 0; } 100% { background-position: 200% 0; } }");
    
    out.println(".profile-header { text-align: center; margin-bottom: 30px; }");
    out.println(".profile-title { font-size: 28px; font-weight: 700; background: linear-gradient(135deg, #667eea, #764ba2); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; margin-bottom: 10px; }");
    out.println(".profile-subtitle { color: #666; font-size: 14px; opacity: 0.8; }");
    
    out.println(".profile-info { display: grid; gap: 20px; }");
    out.println(".info-item { display: flex; align-items: center; padding: 15px; background: rgba(102, 126, 234, 0.05); border-radius: 12px; border-left: 4px solid #667eea; transition: all 0.3s ease; }");
    out.println(".info-item:hover { transform: translateX(5px); background: rgba(102, 126, 234, 0.1); box-shadow: 0 5px 15px rgba(102, 126, 234, 0.1); }");
    
    out.println(".info-icon { width: 40px; height: 40px; border-radius: 50%; background: linear-gradient(135deg, #667eea, #764ba2); display: flex; align-items: center; justify-content: center; margin-right: 15px; font-size: 18px; color: white; flex-shrink: 0; }");
    out.println(".info-content { flex: 1; }");
    out.println(".info-label { font-size: 12px; color: #666; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 2px; font-weight: 600; }");
    out.println(".info-value { font-size: 16px; font-weight: 600; color: #333; }");
    
    out.println(".bmi-status { display: inline-block; padding: 4px 12px; background: " + categoryColor + "; color: white; border-radius: 20px; font-size: 12px; font-weight: 600; margin-left: 10px; animation: pulse 2s infinite; }");
    out.println("@keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.7; } }");
    
    out.println(".action-buttons { margin-top: 30px; display: flex; gap: 15px; }");
    out.println(".btn { flex: 1; padding: 12px 20px; border: none; border-radius: 10px; font-weight: 600; cursor: pointer; transition: all 0.3s ease; text-decoration: none; text-align: center; }");
    out.println(".btn-primary { background: linear-gradient(135deg, #667eea, #764ba2); color: white; }");
    out.println(".btn-secondary { background: rgba(102, 126, 234, 0.1); color: #667eea; border: 1px solid rgba(102, 126, 234, 0.3); }");
    out.println(".btn:hover { transform: translateY(-2px); box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1); }");
    out.println("</style>");
    out.println("</head>");
    out.println("<body>");
    
    // Profile Card HTML
    out.println("<div class='profile-card'>");
    out.println("<div class='profile-header'>");
    out.println("<h1 class='profile-title'>Profile Summary</h1>");
    out.println("<p class='profile-subtitle'>Health & Wellness Overview</p>");
    out.println("</div>");
    
    out.println("<div class='profile-info'>");
    
    // Name
    out.println("<div class='info-item'>");
    out.println("<div class='info-icon'>👤</div>");
    out.println("<div class='info-content'>");
    out.println("<div class='info-label'>Name</div>");
    out.println("<div class='info-value'>" + name + "</div>");
    out.println("</div>");
    out.println("</div>");
    
    // Age
    out.println("<div class='info-item'>");
    out.println("<div class='info-icon'>🎂</div>");
    out.println("<div class='info-content'>");
    out.println("<div class='info-label'>Age</div>");
    out.println("<div class='info-value'>" + age + " years</div>");
    out.println("</div>");
    out.println("</div>");
    
    // Gender
    out.println("<div class='info-item'>");
    out.println("<div class='info-icon'>⚧</div>");
    out.println("<div class='info-content'>");
    out.println("<div class='info-label'>Gender</div>");
    out.println("<div class='info-value'>" + gender + "</div>");
    out.println("</div>");
    out.println("</div>");
    
    // BMI
    out.println("<div class='info-item'>");
    out.println("<div class='info-icon'>📊</div>");
    out.println("<div class='info-content'>");
    out.println("<div class='info-label'>Body Mass Index</div>");
    out.println("<div class='info-value'>" + String.format("%.2f", bmi) + "<span class='bmi-status'>" + category + "</span></div>");
    out.println("</div>");
    out.println("</div>");
    
    out.println("</div>"); // End profile-info
    
    // Action Buttons
    out.println("<div class='action-buttons'>");
    out.println("<a href='#' class='btn btn-primary'>✏️ Edit Profile</a>");
    out.println("<a href='#' class='btn btn-secondary'>📋 View Details</a>");
    out.println("</div>");
    
    out.println("</div>"); // End profile-card
    out.println("</body>");
    out.println("</html>");
}

// Helper method to get category color
private String getCategoryColor1(String category) {
    switch (category.toLowerCase()) {
        case "underweight":
            return "#4facfe";
        case "normal":
            return "#43e97b";
        case "overweight":
            return "#fa709a";
        case "obese":
            return "#ff6b6b";
        default:
            return "#667eea";
    }
}

// Replace your calculateBMI method in Client.java with this enhanced version
private void calculateBMI(HttpServletRequest request, PrintWriter out) {
    double height = Double.parseDouble(request.getParameter("height"));
    double weight = Double.parseDouble(request.getParameter("weight"));
    double bmi = weight / Math.pow(height / 100, 2);
    
    String category = getBMICategory(bmi);
    String tips = getBMITips(category);
    String healthStatus = getHealthStatusFromBMI(bmi);
    String categoryColor = getCategoryColor(category);
    
    //Generate beautiful HTML output
    out.println("<!DOCTYPE html>");
    out.println("<html lang='en'>");
    out.println("<head>");
    out.println("<meta charset='UTF-8'>");
    out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
    out.println("<title>BMI Result - Health Calculator</title>");
    out.println("<style>");
    out.println("* { margin: 0; padding: 0; box-sizing: border-box; }");
    out.println("body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: linear-gradient(-45deg, #667eea, #764ba2, #f093fb, #f5576c); background-size: 400% 400%; animation: gradientShift 15s ease infinite; min-height: 100vh; padding: 20px; display: flex; justify-content: center; align-items: center; }");
    out.println("@keyframes gradientShift { 0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }");
    out.println(".container { max-width: 600px; width: 100%; background: rgba(255, 255, 255, 0.95); border-radius: 25px; padding: 40px; box-shadow: 0 25px 50px rgba(0, 0, 0, 0.2), 0 10px 25px rgba(0, 0, 0, 0.1); backdrop-filter: blur(10px); animation: containerFloat 3s ease-in-out infinite; }");
    out.println("@keyframes containerFloat { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-10px); } }");
    out.println(".header { text-align: center; margin-bottom: 30px; }");
    out.println(".header h1 { color: #2d3748; font-size: 2.5em; margin-bottom: 10px; text-shadow: 2px 2px 4px rgba(0,0,0,0.1); }");
    out.println(".header .emoji { font-size: 3em; animation: bounce 2s infinite; }");
    out.println("@keyframes bounce { 0%, 20%, 60%, 100% { transform: translateY(0); } 40% { transform: translateY(-20px); } 80% { transform: translateY(-10px); } }");
    out.println(".bmi-result { text-align: center; margin-bottom: 30px; }");
    out.println(".bmi-number { font-size: 4em; font-weight: bold; color: " + categoryColor + "; margin-bottom: 15px; text-shadow: 2px 2px 4px rgba(0,0,0,0.1); animation: pulse 2s infinite; }");
    out.println("@keyframes pulse { 0% { transform: scale(1); } 50% { transform: scale(1.05); } 100% { transform: scale(1); } }");
    out.println(".bmi-category { font-size: 1.8em; font-weight: 700; margin-bottom: 20px; padding: 15px 30px; border-radius: 50px; text-align: center; background: linear-gradient(135deg, " + categoryColor + " 0%, " + getDarkerColor(categoryColor) + " 100%); color: white; box-shadow: 0 10px 25px rgba(0,0,0,0.2); text-transform: uppercase; letter-spacing: 1px; }");
    out.println(".health-status { margin: 25px 0; padding: 20px; border-radius: 15px; font-weight: 600; font-size: 1.1em; background: linear-gradient(135deg, #f7fafc 0%, #edf2f7 100%); border-left: 6px solid " + categoryColor + "; color: #2d3748; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }");
    out.println(".tips-section { margin-top: 30px; padding: 25px; background: linear-gradient(135deg, #f0fff4 0%, #e6fffa 100%); border-radius: 20px; border: 2px solid " + categoryColor + "; box-shadow: 0 10px 25px rgba(0,0,0,0.1); }");
    out.println(".tips-section h3 { color: #2d3748; margin-bottom: 20px; font-size: 1.4em; text-align: center; display: flex; align-items: center; justify-content: center; }");
    out.println(".tips-section h3 .icon { font-size: 1.5em; margin-right: 10px; animation: rotate 3s linear infinite; }");
    out.println("@keyframes rotate { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }");
    out.println(".tips-list { color: #2d3748; line-height: 1.8; font-size: 1em; }");
    out.println(".tips-list li { margin-bottom: 10px; padding-left: 10px; position: relative; }");
    out.println(".tips-list li:before { content: '✨'; position: absolute; left: -15px; color: " + categoryColor + "; }");
    out.println(".button-container { text-align: center; margin-top: 35px; }");
    out.println(".back-btn { display: inline-block; padding: 15px 35px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; text-decoration: none; border-radius: 50px; font-weight: 700; font-size: 1.1em; box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4); transition: all 0.4s ease; text-transform: uppercase; letter-spacing: 1px; }");
    out.println(".back-btn:hover { transform: translateY(-5px); box-shadow: 0 15px 35px rgba(102, 126, 234, 0.6); }");
    out.println(".back-btn:active { transform: translateY(-2px); }");
    out.println("@media (max-width: 768px) { .container { margin: 10px; padding: 25px; } .bmi-number { font-size: 3em; } .bmi-category { font-size: 1.4em; } }");
    out.println("</style>");
    out.println("</head>");
    out.println("<body>");
    out.println("<div class='container'>");
    out.println("<div class='header'>");
    out.println("<div class='emoji'>⚖️</div>");
    out.println("<h1>BMI Calculator Result</h1>");
    out.println("</div>");
    
    out.println("<div class='bmi-result'>");
    out.println("<div class='bmi-number'>" + String.format("%.1f", bmi) + "</div>");
    out.println("<div class='bmi-category'>" + category + "</div>");
    out.println("</div>");
    
    out.println("<div class='health-status'>" + healthStatus + "</div>");
    
    out.println("<div class='tips-section'>");
    out.println("<h3><span class='icon'>💡</span>Health Tips For You</h3>");
    out.println("<div class='tips-list'>" + tips + "</div>");
    out.println("</div>");
    
    out.println("<div class='button-container'>");
    out.println("<a href='Client' class='back-btn'>← Back to Calculator</a>");
    out.println("</div>");
    
    out.println("</div>");
    out.println("</body>");
    out.println("</html>");
}

// Add these helper methods to your Client.java class
private String getBMICategory(double bmi) {
    if (bmi < 18.5) {
        return "Underweight";
    } else if (bmi >= 18.5 && bmi < 25.0) {
        return "Normal Weight";
    } else if (bmi >= 25.0 && bmi < 30.0) {
        return "Overweight";
    } else {
        return "Obese";
    }
}

//BMI TIPS
private String getBMITips(String category) {
    switch (category.toLowerCase()) {
        case "underweight":
            return "<ul>" +
                   "<li>Increase calorie intake with nutritious, high-calorie foods</li>" +
                   "<li>Eat smaller, frequent meals (5-6 times daily)</li>" +
                   "<li>Focus on protein-rich foods like meat, fish, eggs, and nuts</li>" +
                   "<li>Add healthy fats like avocado, nuts, and olive oil</li>" +
                   "<li>Do strength training exercises to build muscle mass</li>" +
                   "<li>Consider consulting a nutritionist for a personalized plan</li>" +
                   "</ul>";
        case "normal weight":
            return "<ul>" +
                   "<li>Maintain your current healthy lifestyle</li>" +
                   "<li>Continue balanced diet with vegetables and fruits</li>" +
                   "<li>Exercise 150 minutes of moderate activity per week</li>" +
                   "<li>Stay hydrated with 8-10 glasses of water daily</li>" +
                   "<li>Get adequate sleep (7-8 hours per night)</li>" +
                   "<li>Regular health check-ups to monitor your progress</li>" +
                   "</ul>";
        case "overweight":
            return "<ul>" +
                   "<li>Reduce calorie intake by 300-500 calories per day</li>" +
                   "<li>Increase physical activity to 250-300 minutes per week</li>" +
                   "<li>Choose high-fiber, low-fat foods</li>" +
                   "<li>Avoid sugary drinks and high-fat processed foods</li>" +
                   "<li>Eat more vegetables and fruits</li>" +
                   "<li>Practice portion control and mindful eating</li>" +
                   "</ul>";
        case "obese":
            return "<ul>" +
                   "<li>Consult a doctor or nutritionist for a weight loss plan</li>" +
                   "<li>Aim for gradual weight loss of 1-2 kg per month</li>" +
                   "<li>Start with light exercises like walking</li>" +
                   "<li>Control carbohydrate and sugar intake</li>" +
                   "<li>Monitor blood pressure and blood sugar levels</li>" +
                   "<li>Consider professional support for sustainable changes</li>" +
                   "</ul>";
        default:
            return "<ul><li>Continue maintaining a healthy lifestyle</li></ul>";
    }
}

//BMI STATUS
private String getHealthStatusFromBMI(double bmi) {
    if (bmi < 18.5) {
        return "⚠️ Your weight is below normal range. You may be at risk of nutrient deficiency.";
    } else if (bmi < 25.0) {
        return "✅ Congratulations! Your weight is in the healthy range.";
    } else if (bmi < 30.0) {
        return "⚠️ Your weight is above normal range. Moderate health risk - monitor your lifestyle.";
    } else {
        return "🚨 Your weight is in the high range. High health risk - medical consultation is recommended.";
    }
}

private String getCategoryColor(String category) {
    switch (category.toLowerCase()) {
        case "underweight": return "#3182ce";
        case "normal weight": return "#38a169";
        case "overweight": return "#d69e2e";
        case "obese": return "#e53e3e";
        default: return "#38a169";
    }
}

private String getDarkerColor(String color) {
    switch (color) {
        case "#3182ce": return "#2c5aa0";
        case "#38a169": return "#2f855a";
        case "#d69e2e": return "#b7791f";
        case "#e53e3e": return "#c53030";
        default: return "#2f855a";
    }
}

//calorieburn


private void calculateCalorieBurn(HttpServletRequest request, PrintWriter out) {
    try {
        // CHECK NULL PARAMETERS DULU
        String weightStr = request.getParameter("weight");
        String heightStr = request.getParameter("height");
        String ageStr = request.getParameter("age");
        String gender = request.getParameter("gender");
        
        // KALAU ADA PARAMETER NULL, SHOW ERROR
        if (weightStr == null || heightStr == null || ageStr == null || gender == null) {
            out.println("<html><body>");
            out.println("<h1>Error: Missing Parameters</h1>");
            out.println("<p>Required parameters: weight, height, age, gender</p>");
            out.println("<p>Received parameters:</p>");
            out.println("<ul>");
            out.println("<li>weight: " + weightStr + "</li>");
            out.println("<li>height: " + heightStr + "</li>");
            out.println("<li>age: " + ageStr + "</li>");
            out.println("<li>gender: " + gender + "</li>");
            out.println("</ul>");
            out.println("</body></html>");
            return;
        }
        
        // CONVERT TO NUMBERS - SEKARANG SAFE SEBAB DAH CHECK NULL
        double weight = Double.parseDouble(weightStr);
        double height = Double.parseDouble(heightStr);
        int age = Integer.parseInt(ageStr);
        
        // BMR CALCULATION (BASE METABOLIC RATE)
        double bmr;
        if (gender.equalsIgnoreCase("male")) {
            bmr = 10 * weight + 6.25 * height - 5 * age + 5;
        } else {
            bmr = 10 * weight + 6.25 * height - 5 * age - 161;
        }
        
        // ACTIVITY LEVEL FOR CALORIE BURN
        double activityMultiplier = 1.2;
        String activityLevel = request.getParameter("activityLevel");
        if (activityLevel != null) {
            switch (activityLevel.toLowerCase()) {
                case "light": activityMultiplier = 1.375; break;
                case "moderate": activityMultiplier = 1.55; break;
                case "active": activityMultiplier = 1.725; break;
                case "very active": activityMultiplier = 1.9; break;
            }
        }
        
        // CALCULATE TOTAL DAILY CALORIE BURN
        double dailyCalorieBurn = bmr * activityMultiplier;
        
        // CALCULATE ADDITIONAL EXERCISE CALORIE BURN (ABOVE BMR)
        double exerciseCalorieBurn = dailyCalorieBurn - bmr;
        
        String burnCategory = getCalorieBurnCategory(dailyCalorieBurn);
        String tips = getCalorieBurnTips(burnCategory);
        String categoryColor = getCalorieBurnCategoryColor(burnCategory);
        
        // GENERATE HTML OUTPUT RESULT
        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'>");
        out.println("<head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
        out.println("<title>Calorie Burn Result - Health Calculator</title>");
        out.println("<style>");
        out.println("* { margin: 0; padding: 0; box-sizing: border-box; }");
        out.println("body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: linear-gradient(-45deg, #667eea, #764ba2, #f093fb, #f5576c); background-size: 400% 400%; animation: gradientShift 15s ease infinite; min-height: 100vh; padding: 20px; display: flex; justify-content: center; align-items: center; }");
        out.println("@keyframes gradientShift { 0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }");
        out.println(".container { max-width: 650px; width: 100%; background: rgba(255, 255, 255, 0.95); border-radius: 25px; padding: 40px; box-shadow: 0 25px 50px rgba(0, 0, 0, 0.2), 0 10px 25px rgba(0, 0, 0, 0.1); backdrop-filter: blur(10px); }");
        out.println(".header { text-align: center; margin-bottom: 30px; }");
        out.println(".header h1 { color: #2d3748; font-size: 2.5em; margin-bottom: 10px; text-shadow: 2px 2px 4px rgba(0,0,0,0.1); }");
        out.println(".burn-results { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px; }");
        out.println(".burn-card { background: linear-gradient(135deg, " + categoryColor + " 0%, " + getCalorieDarkerColor(categoryColor) + " 100%); border-radius: 20px; padding: 25px; text-align: center; color: white; }");
        out.println(".burn-number { font-size: 2.5em; font-weight: bold; margin-bottom: 10px; text-shadow: 2px 2px 4px rgba(0,0,0,0.3); }");
        out.println(".burn-label { font-size: 1.1em; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; }");
        out.println(".burn-category { font-size: 1.8em; font-weight: 700; margin-bottom: 20px; padding: 15px 30px; border-radius: 50px; text-align: center; background: linear-gradient(135deg, " + categoryColor + " 0%, " + getCalorieDarkerColor(categoryColor) + " 100%); color: white; text-transform: uppercase; letter-spacing: 1px; }");
        out.println(".tips-section { margin-top: 30px; padding: 25px; background: linear-gradient(135deg, #f0fff4 0%, #e6fffa 100%); border-radius: 20px; border: 2px solid " + categoryColor + "; }");
        out.println(".tips-section h3 { color: #2d3748; margin-bottom: 15px; font-size: 1.5em; }");
        out.println(".tips-list { color: #2d3748; line-height: 1.8; font-size: 1em; }");
        out.println(".button-container { text-align: center; margin-top: 35px; }");
        out.println(".back-btn { display: inline-block; padding: 15px 35px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; text-decoration: none; border-radius: 50px; font-weight: 700; font-size: 1.1em; transition: all 0.4s ease; text-transform: uppercase; letter-spacing: 1px; }");
        out.println(".back-btn:hover { transform: translateY(-3px); box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4); }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<div class='container'>");
        out.println("<div class='header'>");
        out.println("<h1>🔥 Calorie Burn Calculator Result</h1>");
        out.println("</div>");
        
        out.println("<div class='burn-results'>");
        out.println("<div class='burn-card'>");
        out.println("<div class='burn-number'>" + Math.round(dailyCalorieBurn) + "</div>");
        out.println("<div class='burn-label'>Total Daily Burn</div>");
        out.println("</div>");
        out.println("<div class='burn-card'>");
        out.println("<div class='burn-number'>" + Math.round(exerciseCalorieBurn) + "</div>");
        out.println("<div class='burn-label'>Exercise Burn</div>");
        out.println("</div>");
        out.println("</div>");
        
        out.println("<div class='burn-category'>" + burnCategory + "</div>");
        
        out.println("<div class='tips-section'>");
        out.println("<h3>🏃‍♂ Calorie Burning Tips For You</h3>");
        out.println("<div class='tips-list'>" + tips + "</div>");
        out.println("</div>");
        
        out.println("<div class='button-container'>");
        out.println("<a href='Client' class='back-btn'>← Back to Calculator</a>");
        out.println("</div>");
        
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
        
    } catch (Exception e) {
        out.println("<html><body>");
        out.println("<h1>Calculation Error: " + e.getMessage() + "</h1>");
        out.println("</body></html>");
    }
}

// Helper methods - MAKE SURE ADA SEMUA METHOD NI
private String getCalorieBurnCategory(double calories) {
    if (calories < 1800) {
        return "Low Calorie Burner";
    } else if (calories >= 1800 && calories < 2800) {
        return "Moderate Calorie Burner";
    } else {
        return "High Calorie Burner";
    }
}

private String getCalorieBurnTips(String category) {
    switch (category.toLowerCase()) {
        case "low calorie burner":
            return "<ul><li>🚶‍♂ Start with light exercises like walking 30 minutes daily</li><li>🏃‍♀ Gradually increase your activity level with jogging or cycling</li><li>💪 Add resistance training 2-3 times per week</li><li>🎯 Set small, achievable fitness goals to build momentum</li></ul>";
        case "moderate calorie burner":
            return "<ul><li>⚡ Great job! Maintain your current activity level</li><li>🔄 Mix cardio and strength training for optimal results</li><li>📈 Consider increasing intensity or duration gradually</li><li>🥗 Balance your calorie burn with proper nutrition</li></ul>";
        case "high calorie burner":
            return "<ul><li>🔥 Excellent! You're burning lots of calories</li><li>💧 Stay well hydrated during intense workouts</li><li>🛌 Ensure adequate rest and recovery time</li><li>🍽 Fuel your body with nutrient-dense foods</li></ul>";
        default:
            return "<ul><li>📞 Consult a fitness professional for personalized advice</li></ul>";
    }
}

private String getCalorieBurnCategoryColor(String category) {
    switch (category.toLowerCase()) {
        case "low calorie burner": return "#3182ce";
        case "moderate calorie burner": return "#38a169";
        case "high calorie burner": return "#e53e3e";
        default: return "#38a169";
    }
}

private String getCalorieDarkerColor(String color) {
    switch (color) {
        case "#3182ce": return "#2c5aa0";
        case "#38a169": return "#2f855a";
        case "#e53e3e": return "#c53030";
        default: return "#2f855a";
    }
}

//bodyfat - Fixed version with proper error handling
//bodyfat - Enhanced version with age and weight parameters
private void calculateBodyFat(HttpServletRequest request, PrintWriter out) {
    try {
        // Validate and parse parameters with null checks
        String waistStr = request.getParameter("waist");
        String neckStr = request.getParameter("neck");
        String heightStr = request.getParameter("height");
        String weightStr = request.getParameter("weight");
        String ageStr = request.getParameter("age");
        String gender = request.getParameter("gender");
        
        // Check for null or empty parameters
        if (waistStr == null || waistStr.trim().isEmpty() ||
            neckStr == null || neckStr.trim().isEmpty() ||
            heightStr == null || heightStr.trim().isEmpty() ||
            weightStr == null || weightStr.trim().isEmpty() ||
            ageStr == null || ageStr.trim().isEmpty() ||
            gender == null || gender.trim().isEmpty()) {
            
            showErrorPage(out, "Missing required parameters. Please fill in all fields including age and weight.");
            return;
        }
        
        double waist, neck, height, weight, age;
        
        // Parse with error handling
        try {
            waist = Double.parseDouble(waistStr.trim());
            neck = Double.parseDouble(neckStr.trim());
            height = Double.parseDouble(heightStr.trim());
            weight = Double.parseDouble(weightStr.trim());
            age = Double.parseDouble(ageStr.trim());
        } catch (NumberFormatException e) {
            showErrorPage(out, "Invalid number format. Please enter valid measurements, weight, and age.");
            return;
        }
        
        // Validate ranges
        if (waist <= 0 || neck <= 0 || height <= 0 || weight <= 0 || age <= 0) {
            showErrorPage(out, "All measurements, weight, and age must be positive numbers.");
            return;
        }
        
        if (age > 120) {
            showErrorPage(out, "Please enter a valid age (1-120 years).");
            return;
        }
        
        double bodyFat;
        
        // Different formulas for male and female
        if (gender.equalsIgnoreCase("male")) {
            // Enhanced Navy Method for Males with age consideration
            bodyFat = 495 / (1.0324 - 0.19077 * Math.log10(waist - neck) + 0.15456 * Math.log10(height)) - 450;
            
            // Age adjustment for males
            if (age > 30) {
                bodyFat += (age - 30) * 0.02; // Small age adjustment
            }
            
        } else if (gender.equalsIgnoreCase("female")) {
            // For female, we need hip measurement too
            String hipStr = request.getParameter("hip");
            if (hipStr == null || hipStr.trim().isEmpty()) {
                showErrorPage(out, "Hip measurement is required for female body fat calculation.");
                return;
            }
            
            double hip;
            try {
                hip = Double.parseDouble(hipStr.trim());
            } catch (NumberFormatException e) {
                showErrorPage(out, "Invalid hip measurement format.");
                return;
            }
            
            if (hip <= 0) {
                showErrorPage(out, "Hip measurement must be a positive number.");
                return;
            }
            
            // Enhanced Navy Method for Females with age consideration
            bodyFat = 495 / (1.29579 - 0.35004 * Math.log10(waist + hip - neck) + 0.22100 * Math.log10(height)) - 450;
            
            // Age adjustment for females
            if (age > 30) {
                bodyFat += (age - 30) * 0.025; // Small age adjustment for females
            }
            
        } else {
            showErrorPage(out, "Invalid gender. Please select Male or Female.");
            return;
        }
        
        // Alternative calculation using BMI-based method as validation
        double bmi = weight / Math.pow(height/100, 2);
        double bodyFatBMI = calculateBodyFatFromBMI(bmi, age, gender);
        
        // Use average of both methods for more accuracy
        double finalBodyFat = (bodyFat + bodyFatBMI) / 2;
        
        // Check for invalid calculations (NaN or Infinity)
        if (Double.isNaN(finalBodyFat) || Double.isInfinite(finalBodyFat)) {
            showErrorPage(out, "Unable to calculate body fat with the provided measurements. Please check your inputs.");
            return;
        }
        
        // Ensure reasonable range
        if (finalBodyFat < 3) finalBodyFat = 3;
        if (finalBodyFat > 50) finalBodyFat = 50;
        
        String category = getBodyFatCategory(finalBodyFat, gender);
        String tips = getBodyFatTips(category, age, bmi);
        String categoryColor = getBodyFatCategoryColor(category);

        // Generate beautiful HTML output
        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'>");
        out.println("<head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
        out.println("<title>Body Fat Result - Health Calculator</title>");
        out.println("<style>");
        out.println("* { margin: 0; padding: 0; box-sizing: border-box; }");
        out.println("body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: linear-gradient(-45deg, #667eea, #764ba2, #f093fb, #f5576c); background-size: 400% 400%; animation: gradientShift 15s ease infinite; min-height: 100vh; padding: 20px; display: flex; justify-content: center; align-items: center; }");
        out.println("@keyframes gradientShift { 0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }");
        out.println(".container { max-width: 700px; width: 100%; background: rgba(255, 255, 255, 0.95); border-radius: 25px; padding: 40px; box-shadow: 0 25px 50px rgba(0, 0, 0, 0.2), 0 10px 25px rgba(0, 0, 0, 0.1); backdrop-filter: blur(10px); }");
        out.println(".header { text-align: center; margin-bottom: 30px; }");
        out.println(".header h1 { color: #2d3748; font-size: 2.5em; margin-bottom: 10px; text-shadow: 2px 2px 4px rgba(0,0,0,0.1); }");
        out.println(".results-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px; }");
        out.println(".result-card { background: rgba(255, 255, 255, 0.8); border-radius: 15px; padding: 20px; text-align: center; border: 2px solid " + categoryColor + "; }");
        out.println(".bodyfat-result { text-align: center; margin-bottom: 30px; }");
        out.println(".bodyfat-number { font-size: 4em; font-weight: bold; color: " + categoryColor + "; margin-bottom: 15px; text-shadow: 2px 2px 4px rgba(0,0,0,0.1); }");
        out.println(".bodyfat-category { font-size: 1.8em; font-weight: 700; margin-bottom: 20px; padding: 15px 30px; border-radius: 50px; text-align: center; background: linear-gradient(135deg, " + categoryColor + " 0%, " + getBodyFatDarkerColor(categoryColor) + " 100%); color: white; text-transform: uppercase; letter-spacing: 1px; }");
        out.println(".stat-label { font-size: 0.9em; color: #666; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 5px; }");
        out.println(".stat-value { font-size: 1.8em; font-weight: bold; color: #2d3748; }");
        out.println(".tips-section { margin-top: 30px; padding: 25px; background: linear-gradient(135deg, #f0fff4 0%, #e6fffa 100%); border-radius: 20px; border: 2px solid " + categoryColor + "; }");
        out.println(".tips-section h3 { color: #2d3748; margin-bottom: 15px; font-size: 1.4em; }");
        out.println(".tips-list { color: #2d3748; line-height: 1.8; font-size: 1em; }");
        out.println(".button-container { text-align: center; margin-top: 35px; }");
        out.println(".back-btn { display: inline-block; padding: 15px 35px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; text-decoration: none; border-radius: 50px; font-weight: 700; font-size: 1.1em; transition: all 0.4s ease; text-transform: uppercase; letter-spacing: 1px; }");
        out.println(".back-btn:hover { transform: translateY(-3px); box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4); }");
        out.println("@media (max-width: 768px) { .results-grid { grid-template-columns: 1fr; } }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<div class='container'>");
        out.println("<div class='header'>");
        out.println("<h1>Body Fat Analysis Result</h1>");
        out.println("</div>");

        out.println("<div class='bodyfat-result'>");
        out.println("<div class='bodyfat-number'>" + String.format("%.1f", finalBodyFat) + "%</div>");
        out.println("<div class='bodyfat-category'>" + category + "</div>");
        out.println("</div>");
        
        out.println("<div class='results-grid'>");
        out.println("<div class='result-card'>");
        out.println("<div class='stat-label'>Your BMI</div>");
        out.println("<div class='stat-value'>" + String.format("%.1f", bmi) + "</div>");
        out.println("</div>");
        out.println("<div class='result-card'>");
        out.println("<div class='stat-label'>Age Group</div>");
        out.println("<div class='stat-value'>" + getAgeGroup((int)age) + "</div>");
        out.println("</div>");
        out.println("</div>");
        
        out.println("<div class='tips-section'>");
        out.println("<h3>Personalized Health Tips</h3>");
        out.println("<div class='tips-list'>" + tips + "</div>");
        out.println("</div>");
        
        out.println("<div class='button-container'>");
        out.println("<a href='Client' class='back-btn'>← Back to Calculator</a>");
        out.println("</div>");
        
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
        
    } catch (Exception e) {
        // Log the error for debugging
        e.printStackTrace();
        showErrorPage(out, "An unexpected error occurred. Please try again.");
    }
}

// New method to calculate body fat from BMI
private double calculateBodyFatFromBMI(double bmi, double age, String gender) {
    double bodyFat;
    
    if (gender.equalsIgnoreCase("male")) {
        // Deurenberg formula for males
        bodyFat = (1.20 * bmi) + (0.23 * age) - 16.2;
    } else {
        // Deurenberg formula for females
        bodyFat = (1.20 * bmi) + (0.23 * age) - 5.4;
    }
    
    return bodyFat;
}

// New method to get age group
private String getAgeGroup(int age) {
    if (age < 18) return "Youth";
    else if (age < 30) return "Young Adult";
    else if (age < 40) return "Adult";
    else if (age < 50) return "Middle Age";
    else if (age < 65) return "Mature";
    else return "Senior";
}

// Add error page method
private void showErrorPage(PrintWriter out, String errorMessage) {
    out.println("<!DOCTYPE html>");
    out.println("<html lang='en'>");
    out.println("<head>");
    out.println("<meta charset='UTF-8'>");
    out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
    out.println("<title>Error - Health Calculator</title>");
    out.println("<style>");
    out.println("* { margin: 0; padding: 0; box-sizing: border-box; }");
    out.println("body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: linear-gradient(-45deg, #667eea, #764ba2, #f093fb, #f5576c); background-size: 400% 400%; animation: gradientShift 15s ease infinite; min-height: 100vh; padding: 20px; display: flex; justify-content: center; align-items: center; }");
    out.println("@keyframes gradientShift { 0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }");
    out.println(".container { max-width: 600px; width: 100%; background: rgba(255, 255, 255, 0.95); border-radius: 25px; padding: 40px; box-shadow: 0 25px 50px rgba(0, 0, 0, 0.2); text-align: center; }");
    out.println(".error-icon { font-size: 4em; color: #e53e3e; margin-bottom: 20px; }");
    out.println(".error-title { font-size: 2em; color: #2d3748; margin-bottom: 20px; }");
    out.println(".error-message { font-size: 1.2em; color: #4a5568; margin-bottom: 30px; line-height: 1.6; }");
    out.println(".back-btn { display: inline-block; padding: 15px 35px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; text-decoration: none; border-radius: 50px; font-weight: 700; font-size: 1.1em; transition: all 0.4s ease; }");
    out.println(".back-btn:hover { transform: translateY(-3px); box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4); }");
    out.println("</style>");
    out.println("</head>");
    out.println("<body>");
    out.println("<div class='container'>");
    out.println("<div class='error-icon'>⚠️</div>");
    out.println("<h1 class='error-title'>Calculation Error</h1>");
    out.println("<p class='error-message'>" + errorMessage + "</p>");
    out.println("<a href='Client' class='back-btn'>← Back to Calculator</a>");
    out.println("</div>");
    out.println("</body>");
    out.println("</html>");
}

// Enhanced helper methods for body fat calculator
private String getBodyFatCategory(double bodyFat, String gender) {
    if (gender.equalsIgnoreCase("male")) {
        if (bodyFat < 6) return "Essential Fat";
        else if (bodyFat >= 6 && bodyFat < 14) return "Athletic";
        else if (bodyFat >= 14 && bodyFat < 18) return "Fitness";
        else if (bodyFat >= 18 && bodyFat < 25) return "Average";
        else return "Above Average";
    } else {
        if (bodyFat < 16) return "Essential Fat";
        else if (bodyFat >= 16 && bodyFat < 20) return "Athletic";
        else if (bodyFat >= 20 && bodyFat < 25) return "Fitness";
        else if (bodyFat >= 25 && bodyFat < 32) return "Average";
        else return "Above Average";
    }
}

private String getBodyFatTips(String category, double age, double bmi) {
    StringBuilder tips = new StringBuilder();
    
    // Base tips based on category
    switch (category.toLowerCase()) {
        case "essential fat":
            tips.append("<ul><li>You may have very low body fat. Consider consulting a healthcare professional.</li><li>Focus on maintaining adequate nutrition and healthy weight gain.</li>");
            break;
        case "athletic":
            tips.append("<ul><li>Excellent body fat percentage for athletes and fitness enthusiasts.</li><li>Maintain your current fitness routine and balanced nutrition.</li>");
            break;
        case "fitness":
            tips.append("<ul><li>Great body fat percentage for general fitness and health.</li><li>Continue regular exercise and maintain healthy eating habits.</li>");
            break;
        case "average":
            tips.append("<ul><li>Your body fat is within average range.</li><li>Consider increasing physical activity and focusing on strength training.</li>");
            break;
        case "above average":
            tips.append("<ul><li>Consider reducing body fat through a combination of diet and exercise.</li><li>Focus on cardiovascular exercise, strength training, and calorie management.</li>");
            break;
    }
    
    // Age-specific tips
    if (age < 30) {
        tips.append("<li><strong>For your age group:</strong> Focus on building healthy habits that will benefit you long-term.</li>");
    } else if (age >= 30 && age < 50) {
        tips.append("<li><strong>For your age group:</strong> Maintain muscle mass through strength training and consider metabolism-boosting activities.</li>");
    } else {
        tips.append("<li><strong>For your age group:</strong> Focus on maintaining bone density and muscle mass through regular exercise.</li>");
    }
    
    // BMI-specific tips
    if (bmi < 18.5) {
        tips.append("<li><strong>BMI Note:</strong> Your BMI indicates you may be underweight. Consider consulting a nutritionist.</li>");
    } else if (bmi > 25) {
        tips.append("<li><strong>BMI Note:</strong> Your BMI indicates you may benefit from weight management strategies.</li>");
    }
    
    tips.append("</ul>");
    return tips.toString();
}

private String getBodyFatCategoryColor(String category) {
    switch (category.toLowerCase()) {
        case "essential fat": return "#e53e3e";
        case "athletic": return "#38a169";
        case "fitness": return "#38a169";
        case "average": return "#d69e2e";
        case "above average": return "#e53e3e";
        default: return "#38a169";
    }
}

private String getBodyFatDarkerColor(String color) {
    switch (color) {
        case "#e53e3e": return "#c53030";
        case "#38a169": return "#2f855a";
        case "#d69e2e": return "#b7791f";
        default: return "#2f855a";
    }
}

//sleepcalculator

    private void calculateSleep(HttpServletRequest request, PrintWriter out) {
    int age = Integer.parseInt(request.getParameter("age")); // Age in years
    String currentSleep = request.getParameter("currentSleep"); // Current sleep hours (optional)
    
    // Get age-based recommendation
    String recommendation = getSleepRecommendation(age);
    String category = getSleepCategory(age);
    String tips = getSleepTips(category, age);
    String categoryColor = getSleepCategoryColor(category);
    
    // Calculate sleep quality if current sleep is provided
    String sleepQuality = "";
    if (currentSleep != null && !currentSleep.isEmpty()) {
        double current = Double.parseDouble(currentSleep);
        sleepQuality = analyzeSleepQuality(current, age);
    }

    // Generate beautiful HTML output
    out.println("<!DOCTYPE html>");
    out.println("<html lang='en'>");
    out.println("<head>");
    out.println("<meta charset='UTF-8'>");
    out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
    out.println("<title>Sleep Recommendation - Health Calculator</title>");
    out.println("<style>");
    out.println("* { margin: 0; padding: 0; box-sizing: border-box; }");
    out.println("body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: linear-gradient(-45deg, #2D1B69, #11998e, #38ef7d, #667eea); background-size: 400% 400%; animation: gradientShift 15s ease infinite; min-height: 100vh; padding: 20px; display: flex; justify-content: center; align-items: center; }");
    out.println("@keyframes gradientShift { 0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }");
    out.println(".container { max-width: 600px; width: 100%; background: rgba(255, 255, 255, 0.95); border-radius: 25px; padding: 40px; box-shadow: 0 25px 50px rgba(0, 0, 0, 0.2), 0 10px 25px rgba(0, 0, 0, 0.1); backdrop-filter: blur(10px); }");
    out.println(".header { text-align: center; margin-bottom: 30px; }");
    out.println(".header h1 { color: #2d3748; font-size: 2.5em; margin-bottom: 10px; text-shadow: 2px 2px 4px rgba(0,0,0,0.1); }");
    out.println(".sleep-icon { font-size: 3em; margin-bottom: 15px; }");
    out.println(".sleep-result { text-align: center; margin-bottom: 30px; }");
    out.println(".sleep-hours { font-size: 3.5em; font-weight: bold; color: " + categoryColor + "; margin-bottom: 15px; text-shadow: 2px 2px 4px rgba(0,0,0,0.1); }");
    out.println(".sleep-category { font-size: 1.6em; font-weight: 700; margin-bottom: 20px; padding: 15px 30px; border-radius: 50px; text-align: center; background: linear-gradient(135deg, " + categoryColor + " 0%, " + getSleepDarkerColor(categoryColor) + " 100%); color: white; text-transform: uppercase; letter-spacing: 1px; }");
    
    // Add sleep quality section if available
    if (!sleepQuality.isEmpty()) {
        String qualityColor = getSleepQualityColor(sleepQuality);
        out.println(".sleep-quality { margin: 20px 0; padding: 20px; background: linear-gradient(135deg, " + qualityColor + "20 0%, " + qualityColor + "10 100%); border-radius: 15px; border-left: 5px solid " + qualityColor + "; }");
        out.println(".quality-text { font-size: 1.2em; font-weight: 600; color: " + qualityColor + "; }");
    }
    
    out.println(".tips-section { margin-top: 30px; padding: 25px; background: linear-gradient(135deg, #f0f8ff 0%, #e6f3ff 100%); border-radius: 20px; border: 2px solid " + categoryColor + "; }");
    out.println(".tips-section h3 { color: #2d3748; margin-bottom: 15px; font-size: 1.4em; }");
    out.println(".tips-list { color: #2d3748; line-height: 1.8; font-size: 1em; }");
    out.println(".button-container { text-align: center; margin-top: 35px; }");
    out.println(".back-btn { display: inline-block; padding: 15px 35px; background: linear-gradient(135deg, #2D1B69 0%, #11998e 100%); color: white; text-decoration: none; border-radius: 50px; font-weight: 700; font-size: 1.1em; transition: all 0.4s ease; text-transform: uppercase; letter-spacing: 1px; }");
    out.println(".back-btn:hover { transform: translateY(-3px); box-shadow: 0 10px 25px rgba(45, 27, 105, 0.4); }");
    out.println("</style>");
    out.println("</head>");
    out.println("<body>");
    out.println("<div class='container'>");
    out.println("<div class='header'>");
    out.println("<div class='sleep-icon'>🌙</div>");
    out.println("<h1>Sleep Recommendation</h1>");
    out.println("</div>");

    out.println("<div class='sleep-result'>");
    out.println("<div class='sleep-hours'>" + recommendation + "</div>");
    out.println("<div class='sleep-category'>" + category + "</div>");
    out.println("</div>");
    
    // Add sleep quality analysis if available
    if (!sleepQuality.isEmpty()) {
        out.println("<div class='sleep-quality'>");
        out.println("<div class='quality-text'>Current Sleep Status: " + sleepQuality + "</div>");
        out.println("</div>");
    }
    
    out.println("<div class='tips-section'>");
    out.println("<h3>Sleep Tips For Your Age Group</h3>");
    out.println("<div class='tips-list'>" + tips + "</div>");
    out.println("</div>");
    
    out.println("<div class='button-container'>");
    out.println("<a href='Client' class='back-btn'>← Back to Calculator</a>");
    out.println("</div>");
    
    out.println("</div>");
    out.println("</body>");
    out.println("</html>");
}

// Helper methods for sleep calculator
private String getSleepRecommendation(int age) {
    if (age <= 3) return "11–14 hours";
    else if (age <= 5) return "10–13 hours";
    else if (age <= 12) return "9–12 hours";
    else if (age <= 17) return "8–10 hours";
    else if (age <= 25) return "7–9 hours";
    else if (age <= 64) return "7–9 hours";
    else return "7–8 hours";
}

private String getSleepCategory(int age) {
    if (age <= 3) return "Toddler Sleep";
    else if (age <= 5) return "Preschooler Sleep";
    else if (age <= 12) return "School Age Sleep";
    else if (age <= 17) return "Teen Sleep";
    else if (age <= 25) return "Young Adult Sleep";
    else if (age <= 64) return "Adult Sleep";
    else return "Senior Sleep";
}

private String getSleepTips(String category, int age) {
    switch (category.toLowerCase()) {
        case "toddler sleep":
        case "preschooler sleep":
            return "<ul><li>Establish a consistent bedtime routine.</li><li>Create a calm, quiet sleep environment.</li><li>Limit screen time before bed.</li><li>Include daytime naps as needed.</li></ul>";
        case "school age sleep":
            return "<ul><li>Set a regular bedtime and wake time.</li><li>Create a relaxing bedtime routine.</li><li>Keep bedroom cool, dark, and quiet.</li><li>Limit caffeine and electronics before bed.</li></ul>";
        case "teen sleep":
            return "<ul><li>Maintain consistent sleep schedule, even on weekends.</li><li>Avoid caffeine in the afternoon and evening.</li><li>Put away phones and devices 1 hour before bed.</li><li>Create a comfortable sleep environment.</li></ul>";
        case "young adult sleep":
        case "adult sleep":
            return "<ul><li>Stick to a sleep schedule, even on weekends.</li><li>Avoid large meals, caffeine, and alcohol before bedtime.</li><li>Exercise regularly, but not close to bedtime.</li><li>Manage stress through relaxation techniques.</li></ul>";
        case "senior sleep":
            return "<ul><li>Maintain regular sleep-wake times.</li><li>Get morning sunlight exposure.</li><li>Stay physically active during the day.</li><li>Avoid afternoon naps longer than 30 minutes.</li></ul>";
        default:
            return "<ul><li>Maintain a consistent sleep schedule.</li><li>Create a comfortable sleep environment.</li><li>Practice good sleep hygiene.</li></ul>";
    }
}

private String analyzeSleepQuality(double currentSleep, int age) {
    String recommendation = getSleepRecommendation(age);
    // Parse the recommendation range (e.g., "7-9 hours")
    String[] range = recommendation.replace(" hours", "").split("–");
    double minHours = Double.parseDouble(range[0]);
    double maxHours = Double.parseDouble(range[1]);
    
    if (currentSleep < minHours - 1) {
        return "Significantly Under-sleeping";
    } else if (currentSleep < minHours) {
        return "Slightly Under-sleeping";
    } else if (currentSleep >= minHours && currentSleep <= maxHours) {
        return "Optimal Sleep Duration";
    } else if (currentSleep <= maxHours + 1) {
        return "Slightly Over-sleeping";
    } else {
        return "Significantly Over-sleeping";
    }
}

private String getSleepCategoryColor(String category) {
    switch (category.toLowerCase()) {
        case "toddler sleep": return "#ff6b9d";
        case "preschooler sleep": return "#ffa726";
        case "school age sleep": return "#42a5f5";
        case "teen sleep": return "#ab47bc";
        case "young adult sleep": return "#26a69a";
        case "adult sleep": return "#66bb6a";
        case "senior sleep": return "#8d6e63";
        default: return "#66bb6a";
    }
}

private String getSleepQualityColor(String quality) {
    switch (quality.toLowerCase()) {
        case "significantly under-sleeping": return "#f44336";
        case "slightly under-sleeping": return "#ff9800";
        case "optimal sleep duration": return "#4caf50";
        case "slightly over-sleeping": return "#ff9800";
        case "significantly over-sleeping": return "#f44336";
        default: return "#4caf50";
    }
}

private String getSleepDarkerColor(String color) {
    switch (color) {
        case "#ff6b9d": return "#e91e63";
        case "#ffa726": return "#f57c00";
        case "#42a5f5": return "#1976d2";
        case "#ab47bc": return "#7b1fa2";
        case "#26a69a": return "#00695c";
        case "#66bb6a": return "#388e3c";
        case "#8d6e63": return "#5d4037";
        default: return "#388e3c";
    }
}

   // Replace your calculateMenstrualCycle method with this enhanced version

private void calculateMenstrualCycle(HttpServletRequest request, PrintWriter out) {
    try {
        LocalDate start = LocalDate.parse(request.getParameter("lastDate"));
        LocalDate end = LocalDate.parse(request.getParameter("endDate"));

        int cycleLength = (int) ChronoUnit.DAYS.between(start, end);
        LocalDate nextCycle = end.plusDays(cycleLength);
        LocalDate ovulationDate = nextCycle.minusDays(14);
        LocalDate fertileWindowStart = ovulationDate.minusDays(5);
        LocalDate fertileWindowEnd = ovulationDate.plusDays(1);
        
        String cycleStatus = getCycleStatus(cycleLength);
        String cycleColor = getCycleColor(cycleLength);
        String cycleAdvice = getCycleAdvice(cycleLength);

        // Generate beautiful HTML output
        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'>");
        out.println("<head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
        out.println("<title>Menstrual Cycle Result - Health Calculator</title>");
        out.println("<style>");
        out.println("* { margin: 0; padding: 0; box-sizing: border-box; }");
        out.println("body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: linear-gradient(-45deg, #ff9a9e, #fecfef, #fecfef, #ffd1ff); background-size: 400% 400%; animation: gradientShift 15s ease infinite; min-height: 100vh; padding: 20px; display: flex; justify-content: center; align-items: center; }");
        out.println("@keyframes gradientShift { 0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }");
        out.println(".container { max-width: 700px; width: 100%; background: rgba(255, 255, 255, 0.95); border-radius: 25px; padding: 40px; box-shadow: 0 25px 50px rgba(0, 0, 0, 0.2), 0 10px 25px rgba(0, 0, 0, 0.1); backdrop-filter: blur(10px); animation: containerFloat 3s ease-in-out infinite; }");
        out.println("@keyframes containerFloat { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-10px); } }");
        out.println(".header { text-align: center; margin-bottom: 30px; }");
        out.println(".header h1 { color: #2d3748; font-size: 2.5em; margin-bottom: 10px; text-shadow: 2px 2px 4px rgba(0,0,0,0.1); }");
        out.println(".header .emoji { font-size: 3em; animation: bounce 2s infinite; }");
        out.println("@keyframes bounce { 0%, 20%, 60%, 100% { transform: translateY(0); } 40% { transform: translateY(-20px); } 80% { transform: translateY(-10px); } }");
        out.println(".cycle-result { text-align: center; margin-bottom: 30px; }");
        out.println(".cycle-length { font-size: 3.5em; font-weight: bold; color: " + cycleColor + "; margin-bottom: 15px; text-shadow: 2px 2px 4px rgba(0,0,0,0.1); animation: pulse 2s infinite; }");
        out.println("@keyframes pulse { 0% { transform: scale(1); } 50% { transform: scale(1.05); } 100% { transform: scale(1); } }");
        out.println(".cycle-status { font-size: 1.6em; font-weight: 700; margin-bottom: 20px; padding: 15px 30px; border-radius: 50px; text-align: center; background: linear-gradient(135deg, " + cycleColor + " 0%, " + getDarkerCycleColor(cycleColor) + " 100%); color: white; box-shadow: 0 10px 25px rgba(0,0,0,0.2); text-transform: uppercase; letter-spacing: 1px; }");
        out.println(".info-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin: 30px 0; }");
        out.println(".info-card { padding: 25px; border-radius: 20px; text-align: center; box-shadow: 0 10px 25px rgba(0,0,0,0.1); transition: transform 0.3s ease; }");
        out.println(".info-card:hover { transform: translateY(-5px); }");
        out.println(".next-period { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }");
        out.println(".ovulation { background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white; }");
        out.println(".fertile-window { background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white; }");
        out.println(".info-card h3 { font-size: 1.3em; margin-bottom: 15px; display: flex; align-items: center; justify-content: center; }");
        out.println(".info-card h3 .icon { font-size: 1.5em; margin-right: 10px; }");
        out.println(".info-card .date { font-size: 1.8em; font-weight: bold; margin-bottom: 10px; }");
        out.println(".info-card .description { font-size: 1em; opacity: 0.9; }");
        out.println(".advice-section { margin-top: 30px; padding: 25px; background: linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%); border-radius: 20px; border: 2px solid " + cycleColor + "; box-shadow: 0 10px 25px rgba(0,0,0,0.1); }");
        out.println(".advice-section h3 { color: #2d3748; margin-bottom: 20px; font-size: 1.4em; text-align: center; display: flex; align-items: center; justify-content: center; }");
        out.println(".advice-section h3 .icon { font-size: 1.5em; margin-right: 10px; animation: rotate 3s linear infinite; }");
        out.println("@keyframes rotate { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }");
        out.println(".advice-list { color: #2d3748; line-height: 1.8; font-size: 1em; }");
        out.println(".advice-list li { margin-bottom: 10px; padding-left: 10px; position: relative; }");
        out.println(".advice-list li:before { content: '🌸'; position: absolute; left: -15px; }");
        out.println(".button-container { text-align: center; margin-top: 35px; }");
        out.println(".back-btn { display: inline-block; padding: 15px 35px; background: linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%); color: #2d3748; text-decoration: none; border-radius: 50px; font-weight: 700; font-size: 1.1em; box-shadow: 0 10px 25px rgba(255, 154, 158, 0.4); transition: all 0.4s ease; text-transform: uppercase; letter-spacing: 1px; }");
        out.println(".back-btn:hover { transform: translateY(-5px); box-shadow: 0 15px 35px rgba(255, 154, 158, 0.6); }");
        out.println("@media (max-width: 768px) { .container { margin: 10px; padding: 25px; } .info-grid { grid-template-columns: 1fr; } }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<div class='container'>");
        out.println("<div class='header'>");
        out.println("<div class='emoji'>🌸</div>");
        out.println("<h1>Menstrual Cycle Tracker</h1>");
        out.println("</div>");
        
        out.println("<div class='cycle-result'>");
        out.println("<div class='cycle-length'>" + cycleLength + " Days</div>");
        out.println("<div class='cycle-status'>" + cycleStatus + "</div>");
        out.println("</div>");
        
        out.println("<div class='info-grid'>");
        
        out.println("<div class='info-card next-period'>");
        out.println("<h3><span class='icon'>📅</span>Next Period</h3>");
        out.println("<div class='date'>" + nextCycle.toString() + "</div>");
        out.println("<div class='description'>Expected start date</div>");
        out.println("</div>");
        
        out.println("<div class='info-card ovulation'>");
        out.println("<h3><span class='icon'>🥚</span>Ovulation</h3>");
        out.println("<div class='date'>" + ovulationDate.toString() + "</div>");
        out.println("<div class='description'>Most fertile day</div>");
        out.println("</div>");
        
        out.println("<div class='info-card fertile-window'>");
        out.println("<h3><span class='icon'>💕</span>Fertile Window</h3>");
        out.println("<div class='date'>" + fertileWindowStart.toString() + "</div>");
        out.println("<div style='font-size: 1.2em; margin: 5px 0;'>to</div>");
        out.println("<div class='date'>" + fertileWindowEnd.toString() + "</div>");
        out.println("</div>");
        
        out.println("</div>");
        
        out.println("<div class='advice-section'>");
        out.println("<h3><span class='icon'>💡</span>Health Tips For Your Cycle</h3>");
        out.println("<div class='advice-list'>" + cycleAdvice + "</div>");
        out.println("</div>");
        
        out.println("<div class='button-container'>");
        out.println("<a href='Client' class='back-btn'>← Back to Calculator</a>");
        out.println("</div>");
        
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
        
    } catch (Exception e) {
        out.println("<!DOCTYPE html>");
        out.println("<html><head><title>Error</title>");
        out.println("<style>body{font-family:Arial;text-align:center;padding:50px;background:#ff9a9e;color:white;}</style>");
        out.println("</head><body>");
        out.println("<h1>❌ Error</h1>");
        out.println("<p>Invalid dates entered. Please check your dates and try again.</p>");
        out.println("<a href='Client?calculator=cycle' style='color:white;'>← Try Again</a>");
        out.println("</body></html>");
    }
}

// Helper methods for menstrual cycle calculator
private String getCycleStatus(int cycleLength) {
    if (cycleLength < 21) {
        return "Short Cycle";
    } else if (cycleLength >= 21 && cycleLength <= 35) {
        return "Normal Cycle";
    } else {
        return "Long Cycle";
    }
}

private String getCycleColor(int cycleLength) {
    if (cycleLength < 21) {
        return "#e53e3e";
    } else if (cycleLength >= 21 && cycleLength <= 35) {
        return "#38a169";
    } else {
        return "#d69e2e";
    }
}

private String getDarkerCycleColor(String color) {
    switch (color) {
        case "#e53e3e": return "#c53030";
        case "#38a169": return "#2f855a";
        case "#d69e2e": return "#b7791f";
        default: return "#2f855a";
    }
}

private String getCycleAdvice(int cycleLength) {
    if (cycleLength < 21) {
        return "<ul>" +
               "<li>Consult with a gynecologist about your short cycle</li>" +
               "<li>Track symptoms and mood changes</li>" +
               "<li>Maintain a healthy diet rich in iron</li>" +
               "<li>Consider stress management techniques</li>" +
               "<li>Regular exercise can help regulate hormones</li>" +
               "<li>Keep a detailed menstrual diary</li>" +
               "</ul>";
    } else if (cycleLength >= 21 && cycleLength <= 35) {
        return "<ul>" +
               "<li>Your cycle length is perfectly normal</li>" +
               "<li>Stay hydrated and eat a balanced diet</li>" +
               "<li>Regular exercise helps with cramps</li>" +
               "<li>Track your cycle for family planning</li>" +
               "<li>Use heat therapy for menstrual pain</li>" +
               "<li>Consider iron supplements during heavy flow days</li>" +
               "</ul>";
    } else {
        return "<ul>" +
               "<li>Consider consulting a healthcare provider</li>" +
               "<li>Monitor for PCOS or thyroid issues</li>" +
               "<li>Maintain a healthy weight</li>" +
               "<li>Reduce stress through meditation or yoga</li>" +
               "<li>Track ovulation signs more carefully</li>" +
               "<li>Consider lifestyle changes to regulate cycle</li>" +
               "</ul>";
    }
}


//age calculator
    private void calculateAge(HttpServletRequest request, PrintWriter out) {
    String ic = request.getParameter("ic");
    
    // Validate IC parameter
    if (ic == null || ic.trim().isEmpty()) {
        displayError(out, "IC number is required.");
        return;
    }
    
    ic = ic.trim();
    
    // Validate IC length
    if (ic.length() < 6) {
        displayError(out, "Invalid IC format. IC must contain at least 6 digits.");
        return;
    }
    
    try {
        // Extract date components from IC
        int year = Integer.parseInt(ic.substring(0, 2));
        int month = Integer.parseInt(ic.substring(2, 4));
        int day = Integer.parseInt(ic.substring(4, 6));
        
        // Validate month and day ranges
        if (month < 1 || month > 12) {
            displayError(out, "Invalid month in IC number.");
            return;
        }
        
        if (day < 1 || day > 31) {
            displayError(out, "Invalid day in IC number.");
            return;
        }
        
        // Determine full year
        int currentYear = LocalDate.now().getYear() % 100;
        int fullYear = (year > currentYear) ? 1900 + year : 2000 + year;
        
        // Create birth date and validate
        LocalDate birthDate;
        try {
            birthDate = LocalDate.of(fullYear, month, day);
        } catch (DateTimeException e) {
            displayError(out, "Invalid date in IC number.");
            return;
        }
        
        // Check if birth date is not in the future
        if (birthDate.isAfter(LocalDate.now())) {
            displayError(out, "Birth date cannot be in the future.");
            return;
        }
        
        // Calculate age
        int age = (int) ChronoUnit.YEARS.between(birthDate, LocalDate.now());
        
        // Display dashboard result
        displayAgeDashboard(out, age, birthDate);
        
    } catch (NumberFormatException e) {
        displayError(out, "Invalid IC number format. Please enter numeric digits only.");
    } catch (StringIndexOutOfBoundsException e) {
        displayError(out, "Invalid IC format. Please check your IC number.");
    } catch (Exception e) {
        displayError(out, "An error occurred while processing your IC number.");
    }
}

private void displayError(PrintWriter out, String message) {
    out.println("<div class='error-card'>");
    out.println("<h2>❌ Error</h2>");
    out.println("<p>" + escapeHtml(message) + "</p>");
    out.println("</div>");
}

private void displayAgeDashboard(PrintWriter out, int age, LocalDate birthDate) {
    String ageCategory = getAgeCategory(age);
    String nextBirthday = calculateNextBirthday(birthDate);
    String lifestage = getLifeStage(age);
    
    out.println("<div class='age-dashboard'>");
    
    // Header
    out.println("<div class='dashboard-header'>");
    out.println("<h1>🎂 Age Calculator</h1>");
    out.println("</div>");
    
    // Main age display
    out.println("<div class='age-main'>");
    out.println("<h2 class='age-number'>" + age + " Years</h2>");
    out.println("<div class='age-status " + ageCategory.toLowerCase().replace(" ", "-") + "'>");
    out.println(ageCategory.toUpperCase());
    out.println("</div>");
    out.println("</div>");
    
    // Info cards container
    out.println("<div class='info-cards'>");
    
    // Birth Date card
    out.println("<div class='info-card birth-card'>");
    out.println("<div class='card-icon'>📅</div>");
    out.println("<div class='card-title'>Birth Date</div>");
    out.println("<div class='card-date'>" + formatDate(birthDate) + "</div>");
    out.println("<div class='card-subtitle'>Your birthday</div>");
    out.println("</div>");
    
    // Next Birthday card
    out.println("<div class='info-card birthday-card'>");
    out.println("<div class='card-icon'>🎉</div>");
    out.println("<div class='card-title'>Next Birthday</div>");
    out.println("<div class='card-date'>" + nextBirthday + "</div>");
    out.println("<div class='card-subtitle'>Days until celebration</div>");
    out.println("</div>");
    
    // Life Stage card
    out.println("<div class='info-card lifestage-card'>");
    out.println("<div class='card-icon'>🌟</div>");
    out.println("<div class='card-title'>Life Stage</div>");
    out.println("<div class='card-date'>" + lifestage + "</div>");
    out.println("<div class='card-subtitle'>Current phase</div>");
    out.println("</div>");
    
    out.println("</div>"); // End info-cards
    out.println("</div>"); // End dashboard
    
    // Add CSS styling
    addDashboardCSS(out);
}

private String getAgeCategory(int age) {
    if (age < 13) return "Child";
    else if (age < 20) return "Teenager";
    else if (age < 35) return "Young Adult";
    else if (age < 50) return "Adult";
    else if (age < 65) return "Middle Aged";
    else return "Senior";
}

private String calculateNextBirthday(LocalDate birthDate) {
    LocalDate today = LocalDate.now();
    LocalDate nextBirthday = birthDate.withYear(today.getYear());
    
    if (nextBirthday.isBefore(today) || nextBirthday.isEqual(today)) {
        nextBirthday = nextBirthday.plusYears(1);
    }
    
    long daysUntil = ChronoUnit.DAYS.between(today, nextBirthday);
    
    if (daysUntil == 0) {
        return "Today! 🎂";
    } else if (daysUntil == 1) {
        return "Tomorrow";
    } else {
        return daysUntil + " days";
    }
}

private String getLifeStage(int age) {
    if (age < 13) return "Childhood";
    else if (age < 20) return "Adolescence";
    else if (age < 30) return "Early Adulthood";
    else if (age < 40) return "Prime Years";
    else if (age < 55) return "Midlife";
    else if (age < 70) return "Pre-retirement";
    else return "Golden Years";
}

private String formatDate(LocalDate date) {
    return date.getDayOfMonth() + "/" + date.getMonthValue() + "/" + date.getYear();
}

private void addDashboardCSS(PrintWriter out) {
    out.println("<style>");
    out.println(".age-dashboard { max-width: 600px; margin: 20px auto; font-family: Arial, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 20px; padding: 30px; color: white; }");
    out.println(".dashboard-header { text-align: center; margin-bottom: 30px; }");
    out.println(".dashboard-header h1 { margin: 0; font-size: 28px; font-weight: bold; }");
    out.println(".age-main { text-align: center; margin-bottom: 30px; }");
    out.println(".age-number { font-size: 48px; margin: 10px 0; font-weight: bold; color: #fff; }");
    out.println(".age-status { display: inline-block; padding: 12px 30px; border-radius: 25px; font-weight: bold; font-size: 16px; letter-spacing: 1px; }");
    out.println(".child { background-color: #ff6b6b; }");
    out.println(".teenager { background-color: #4ecdc4; }");
    out.println(".young-adult { background-color: #45b7d1; }");
    out.println(".adult { background-color: #96ceb4; }");
    out.println(".middle-aged { background-color: #feca57; }");
    out.println(".senior { background-color: #ff9ff3; }");
    out.println(".info-cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 20px; }");
    out.println(".info-card { background: rgba(255,255,255,0.15); backdrop-filter: blur(10px); border-radius: 15px; padding: 20px; text-align: center; border: 1px solid rgba(255,255,255,0.2); }");
    out.println(".card-icon { font-size: 24px; margin-bottom: 8px; }");
    out.println(".card-title { font-size: 14px; font-weight: bold; margin-bottom: 8px; opacity: 0.9; }");
    out.println(".card-date { font-size: 18px; font-weight: bold; margin-bottom: 5px; }");
    out.println(".card-subtitle { font-size: 12px; opacity: 0.8; }");
    out.println(".error-card { max-width: 400px; margin: 20px auto; padding: 20px; background: #ff6b6b; color: white; border-radius: 15px; text-align: center; }");
    out.println("</style>");
}

private String escapeHtml(String text) {
    if (text == null) return "";
    return text.replace("&", "&amp;")
               .replace("<", "&lt;")
               .replace(">", "&gt;")
               .replace("\"", "&quot;")
               .replace("'", "&#x27;");
}
    }
