package fitness;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.regex.Pattern;
import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.xml.ws.soap.SOAPFaultException;
import javax.xml.namespace.QName;
import javax.xml.soap.SOAPFactory;
import javax.xml.soap.SOAPFault;

@WebService
public class FitnessServer {

    @WebMethod
    public String displayUserInfo(String name, String ic, String dob) {
        if (!Pattern.matches("[0-9]{12}", ic)) {
            throw createSOAPFault("Invalid IC format. Must be 12 digits.");
        }
        if (!Pattern.matches("\\d{4}-\\d{2}-\\d{2}", dob)) {
            throw createSOAPFault("Invalid date format. Use YYYY-MM-DD.");
        }
        int age = determineAge(dob);
        return String.format("Hello %s! You are %d years old. %s", name, age, getHealthStatus(0, age));
    }

    @WebMethod
    public int determineAge(String dob) {
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate birthDate = LocalDate.parse(dob, formatter);
            return Period.between(birthDate, LocalDate.now()).getYears();
        } catch (DateTimeParseException e) {
            throw createSOAPFault("Invalid date format. Use YYYY-MM-DD.");
        }
    }

    // REPLACE calculateBMI method dengan ini
@WebMethod
public String calculateBMI(double weight, double height) {
    if (weight <= 0 || height <= 0) {
        throw createSOAPFault("Weight and height must be positive.");
    }
    double bmi = weight / (height * height);
    String category = getBMICategory(bmi);
    String tips = getBMITips(category);
    String healthStatus = getHealthStatusFromBMI(bmi);
    
    // Return HTML instead of plain text
    return generateBMIHTML(bmi, category, tips, healthStatus);
}
private String getBMICategory(double bmi) {
    if (bmi < 18.5) {
        return "Underweight";
    } else if (bmi >= 18.5 && bmi < 25.0) {
        return "Normal";
    } else if (bmi >= 25.0 && bmi < 30.0) {
        return "Overweight";
    } else {
        return "Obese";
    }
}
// ADD method baru ini
private String generateBMIHTML(double bmi, String category, String tips, String healthStatus) {
    String categoryColor = getCategoryColor(category);
    
    return "<!DOCTYPE html>" +
    "<html lang='ms'>" +
    "<head>" +
        "<meta charset='UTF-8'>" +
        "<meta name='viewport' content='width=device-width, initial-scale=1.0'>" +
        "<title>BMI Result</title>" +
        "<style>" +
            "body { font-family: 'Segoe UI', sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding: 20px; margin: 0; }" +
            ".container { max-width: 600px; margin: 0 auto; background: rgba(255, 255, 255, 0.95); border-radius: 20px; padding: 30px; box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1); }" +
            ".bmi-value { text-align: center; margin-bottom: 20px; }" +
            ".bmi-number { font-size: 3em; font-weight: bold; color: " + categoryColor + "; margin-bottom: 10px; }" +
            ".bmi-category { font-size: 1.5em; font-weight: 600; margin-bottom: 20px; padding: 10px 20px; border-radius: 10px; text-align: center; background: " + categoryColor + "; color: white; }" +
            ".health-status { margin: 20px 0; padding: 15px; border-radius: 10px; font-weight: 600; background: #f7fafc; border-left: 5px solid " + categoryColor + "; }" +
            ".tips-section { margin-top: 25px; padding: 20px; background: #f7fafc; border-radius: 10px; border-left: 5px solid #667eea; }" +
            ".tips-section h3 { color: #4a5568; margin-bottom: 15px; }" +
            ".tips-list { color: #2d3748; line-height: 1.6; }" +
            ".back-btn { display: inline-block; margin-top: 20px; padding: 10px 20px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; text-decoration: none; border-radius: 10px; font-weight: 600; }" +
        "</style>" +
    "</head>" +
    "<body>" +
        "<div class='container'>" +
            "<div class='bmi-value'>" +
                "<div class='bmi-number'>" + String.format("%.1f", bmi) + "</div>" +
                "<div class='bmi-category'>" + category + "</div>" +
            "</div>" +
            "<div class='health-status'>" + healthStatus + "</div>" +
            "<div class='tips-section'>" +
                "<h3>💡 Tips Kesihatan Untuk Anda</h3>" +
                "<div class='tips-list'>" + tips + "</div>" +
            "</div>" +
            "<a href='javascript:history.back()' class='back-btn'>← Kembali</a>" +
        "</div>" +
    "</body>" +
    "</html>";
}

// ADD method baru ini
private String getCategoryColor(String category) {
    switch (category.toLowerCase()) {
        case "underweight": return "#3182ce";
        case "normal": return "#38a169";
        case "overweight": return "#d69e2e";
        case "obese": return "#e53e3e";
        default: return "#38a169";
    }
}

// ADD method baru ini  
private String getBMITips(String category) {
    switch (category.toLowerCase()) {
        case "underweight":
            return "• Tingkatkan pengambilan kalori dengan makanan berkhasiat tinggi<br>" +
                   "• Makan dalam porsi kecil tapi kerap (5-6 kali sehari)<br>" +
                   "• Fokus pada protein seperti daging, ikan, telur, dan kekacang<br>" +
                   "• Tambah lemak sihat seperti avocado, kacang, dan minyak zaitun<br>" +
                   "• Buat senaman kekuatan untuk membina otot";
        case "normal":
            return "• Teruskan gaya hidup sihat yang sedia ada<br>" +
                   "• Kekalkan diet seimbang dengan sayur-sayuran dan buah-buahan<br>" +
                   "• Lakukan senaman aerobik 150 minit seminggu<br>" +
                   "• Minum air yang mencukupi (8-10 gelas sehari)<br>" +
                   "• Tidur yang cukup (7-8 jam sehari)";
        case "overweight":
            return "• Kurangkan pengambilan kalori sebanyak 300-500 kalori sehari<br>" +
                   "• Tingkatkan aktiviti fizikal kepada 250-300 minit seminggu<br>" +
                   "• Pilih makanan tinggi serat dan rendah lemak<br>" +
                   "• Elakkan makanan manis dan berlemak tinggi<br>" +
                   "• Makan sayur-sayuran dan buah-buahan lebih banyak";
        case "obese":
            return "• Rujuk doktor atau ahli pemakanan untuk rancangan penurunan berat<br>" +
                   "• Sasarkan penurunan berat 1-2 kg sebulan<br>" +
                   "• Mulakan dengan senaman ringan seperti berjalan kaki<br>" +
                   "• Kawal pengambilan karbohidrat dan gula<br>" +
                   "• Pantau tekanan darah dan paras gula dalam darah";
        default:
            return "• Teruskan gaya hidup sihat";
    }
}

// ADD method baru ini
private String getHealthStatusFromBMI(double bmi) {
    if (bmi < 18.5) {
        return "⚠️ Berat badan anda kurang daripada normal. Mungkin berisiko kekurangan nutrien.";
    } else if (bmi < 25.0) {
        return "✅ Tahniah! Berat badan anda dalam julat yang sihat.";
    } else if (bmi < 30.0) {
        return "⚠️ Berat badan anda melebihi normal. Risiko kesihatan sederhana - pantau gaya hidup.";
    } else {
        return "🚨 Berat badan anda tinggi. Risiko kesihatan tinggi - disarankan rujuk doktor.";
    }
}
    @WebMethod
    public String calculateBodyFatPercentage(double bmi, int age, String gender) {
        if (age <= 0 || (!gender.equalsIgnoreCase("male") && !gender.equalsIgnoreCase("female"))) {
            throw createSOAPFault("Invalid age or gender.");
        }
        int genderValue = gender.equalsIgnoreCase("male") ? 1 : 0;
        double bodyFat = 1.20 * bmi + 0.23 * age - 10.8 * genderValue - 5.4;
        String category = getBodyFatCategory(bodyFat, gender);
        String recommendation = getBodyFatRecommendation(bodyFat, gender);
        return String.format("Your body fat percentage is %.2f%%. Category: %s. %s", bodyFat, category, recommendation);
    }

    private String getBodyFatCategory(double bodyFat, String gender) {
        if (gender.equalsIgnoreCase("male")) {
            if (bodyFat < 6) return "Essential fat";
            else if (bodyFat < 14) return "Athletes";
            else if (bodyFat < 18) return "Fitness";
            else if (bodyFat < 25) return "Average";
            else return "Obese";
        } else {
            if (bodyFat < 14) return "Essential fat";
            else if (bodyFat < 21) return "Athletes";
            else if (bodyFat < 25) return "Fitness";
            else if (bodyFat < 32) return "Average";
            else return "Obese";
        }
    }

    private String getBodyFatRecommendation(double bodyFat, String gender) {
        String category = getBodyFatCategory(bodyFat, gender);
        switch (category) {
            case "Essential fat":
                return "Body fat is very low. Consult a healthcare provider.";
            case "Athletes":
                return "Excellent body fat level. Maintain with current fitness regime.";
            case "Fitness":
                return "Healthy body fat level. Keep it up!";
            case "Average":
                return "Within average range. Consider improving your lifestyle.";
            case "Obese":
                return "High body fat level. Recommended to consult a doctor.";
            default:
                return "Unable to determine recommendation.";
        }
    }

    @WebMethod
    public String calculateCaloriesBurned(double weight, double duration, String activityType) {
        if (weight <= 0 || duration <= 0) {
            throw createSOAPFault("Weight and duration must be positive.");
        }
        double met;
        switch (activityType.toLowerCase()) {
            case "running": met = 9.8; break;
            case "cycling": met = 7.5; break;
            case "swimming": met = 8.0; break;
            default: throw createSOAPFault("Invalid activity type. Use running, cycling, or swimming.");
        }
        double calories = met * weight * (duration / 60.0);
        return String.format("You burned approximately %.2f calories.", calories);
    }

    @WebMethod
    public String sleepRecommendation(int age) {
        if (age < 0) {
            throw createSOAPFault("Invalid age.");
        }
        int recommendedHours;
        if (age <= 5) recommendedHours = 11;
        else if (age <= 13) recommendedHours = 9;
        else if (age <= 17) recommendedHours = 8;
        else recommendedHours = 7;
        String tip = getSleepTips(age);
        return String.format("Recommended sleep: %d hours. Tip: %s", recommendedHours, tip);
    }

    private String getSleepTips(int age) {
        if (age <= 5) return "Set consistent bedtime, avoid sugar before bed.";
        else if (age <= 17) return "Avoid screens before bed, keep room dark.";
        else return "Avoid caffeine, maintain sleep schedule even on weekends.";
    }

    @WebMethod
    public String trackMenstrualCycle(String phase) {
        if (phase == null || phase.trim().isEmpty()) {
            throw createSOAPFault("Phase cannot be empty.");
        }
        phase = phase.toLowerCase();
        switch (phase) {
            case "menstrual":
            case "follicular":
            case "ovulation":
            case "luteal":
                String tips = getMenstrualHealthTips(phase);
                return String.format("You're in the %s phase. Tips: %s", phase, tips);
            default:
                throw createSOAPFault("Invalid phase. Use menstrual, follicular, ovulation, or luteal.");
        }
    }

    private String getMenstrualHealthTips(String phase) {
        switch (phase.toLowerCase()) {
            case "menstrual":
                return "Rest, stay hydrated, and consider light activity.";
            case "follicular":
                return "Energy rising — great time for creative tasks.";
            case "ovulation":
                return "Peak energy — ideal for intense workouts.";
            case "luteal":
                return "Mood changes common — prioritize relaxation.";
            default:
                return "Track your cycle for better insight.";
        }
    }

    private String getHealthStatus(double bmi, int age) {
        if (age < 18) return "Monitor your health with regular checkups.";
        if (bmi == 0) return "Age verified. Continue maintaining a healthy lifestyle.";
        if (bmi < 18.5) return "May be at risk of nutrient deficiency.";
        else if (bmi < 25.0) return "Healthy weight range.";
        else if (bmi < 30.0) return "Mild health risk. Monitor lifestyle.";
        else return "High health risk. Medical consultation advised.";
    }

    private SOAPFaultException createSOAPFault(String message) {
        try {
            SOAPFactory soapFactory = SOAPFactory.newInstance();
            SOAPFault fault = soapFactory.createFault(message, new QName("http://schemas.xmlsoap.org/soap/envelope/", "Client"));
            return new SOAPFaultException(fault);
        } catch (Exception e) {
            throw new RuntimeException("Error creating SOAP fault: " + e.getMessage(), e);
        }
    }
}
